function z=cgml_solveprecb(r,a,d,l,precond,tb,param);
%CGML_SOLVEPRECB solves M z = r
%
% a matrix
% d and l computed by initprec
% precond - type of preconditioning
% ='no' M=I
% ='sc' diagonal
% ='ic' IC(0)
% ='ch' IC(epsilon)
% ='lv' IC(level)
% ='ei' modified IC of Eijkhout using levels
% ='sh' shifted alg of Manteuffel using levels
% ='po' least square polynomial
% ='ai' AINV
% ='sa' SAINV
% ='tw' Tang and Wan approximate inverse
% ='bc' block Incomplete Cholesky
% ='ml' multilevel 
% param - parameter needed by some preconditioners
% = nothing for 'no' and 'ic'
% = epsilon for 'ch'
% = level for 'lv'
% = degree of polynomial for 'po'
% = tau for 'ai'
% = nothing for 'tw'
% = number of levels for 'ml'
% 
%
% output
% z - solution of M z = r
%
% Author G. Meurant
% Feb 2001
%
n=size(a,1);
switch precond
case 'no'
 z=r;
case 'sc'
 z=r./d;
case {'ic','ch','lv','ss','ei','sh'}
 y=l\r;
 z=l'\(d.*y);
case 'bc'
 y=l\r;
 yy=d\y;
 z=l'\yy;
case 'tw'
 z=l*r;
case 'po'
 k=param;
 if isempty(k)
  k=1;
 end
 s=d(1:k+2);
 ss=sum(s(1:k+2).^2);
 b=s/ss;
 lmin=d(k+3);
 lmax=d(k+4);
 z(:,k+1)=b(k+2)*r;
 z(:,k)=b(k+1)*r+(2/(lmax-lmin))*(2*a*z(:,k+1)-(lmax+lmin)*z(:,k+1));
 for j=k-1:-1:1
  z(:,j)=b(j+1)*r+(2/(lmax-lmin))*(2*a*z(:,j+1)-(lmax+lmin)*z(:,j+1))-z(:,j+2);
 end
 u=(4/(lmin-lmax))*s(k+1)*z(:,k+1);
 for j=k-1:-1:1
  u=(4/(lmin-lmax))*s(j+1)*z(:,j+1)+u;
 end
 z=sqrt(2/pi)*(2/(lmin-lmax))*z(:,1)+u;
case {'ai','sa'}
 y=l'*r;
 z=l*(d.*y);
end


