function [s]=cgml_influin(a,m,alp);
%CGML_INFLUIN influence matrix of m
% computes a sparse matrix s of ones where |m(i,j)| >= alp * max_i |m(i,k)|
% if there is no element for a row, take the largest one
% note that a is not used ????
%
% author G. Meurant
% Aug 2000
%

maxs=max(abs(m'))';
n=size(m,1);
s=sparse(n,n);
err=0;
for i=1:n
 ind= find(abs(m(i,:)) >= alp*maxs(i));
 indm=find(abs(m(i,:)) > 0);
 if length(indm) <=1
  err=1;
 end
 if length(ind) == 1
  b=full(m(i,:));
  b(i)=0;
  [maxm,j]=max(abs(b));
  s(i,j)=1;
 else
  s(i,ind)=spones(ind);
 end
end
s=s-diag(diag(s));
if nnz(s) == 0
 error('CGML_INFLUIN: influin, S is empty!')
end
if err == 1
 disp('CGML_INFLUIN: pb with some empty rows')
end

