function [f,c,w]=cgml_coarsenhmis(a,s);
%CGML_COARSENHMIS HMIS coarsening algorithm, find the fine and coarse nodes
%
% s is an influence matrix for a
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w are the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% author G. Meurant
% Mar 2009
%

f=[];
c=[];
n=size(s,1);
aa=a-diag(diag(a));

% use the same weights as in CLJP
%w=cgml_wght_cljp(a,s);
% randomized weights
w=cgml_wght_r(a,s);
dim=0;

ind=[];
for i=1:n
 indi=find(s(:,i) == 0);
 if isempty(indi)
  ind=[ind i];
 end % if
end % for i
% flag these nodes as fines
if length(ind) > 0
 f=[f ind];
 w(ind)=-50;
 dim=dim+length(ind);
end

while dim < n
 % find an independent set of nodes
 % use the coarse nodes of the result of the Ruge-Stuben algorithm
 if dim == 0
  [ff,cc,ww]=cgml_coarsenstnew(a,s);
  isn=sort(cc);
 else
  isn=cgml_ind_set(w,s);
 end

 if isempty(isn)
  % flag the remaining nodes as fine if not all their neighbours are fine
  ind=find(w > -50);
  indc=[];
  indf=[];
  for ii=1:length(ind)
   i=ind(ii);
   %ineighb=cgml_neighb(a,i);
   % use S instead for interpolation
   ineighb=cgml_neighb1(s,i);
   %ineighb=cgml_fmt(ineighb,[i]);
   sw=sum(w(ineighb));
   if sw == -50*length(ineighb)
    indc=[indc i];
   else
    indf=[indf i];
   end
  end
  
  w(indc)=-100;
  c=[c indc];
    
  w(indf)=-50;
  f=[f indf];
  dim=dim+length(ind);
  
 else
  % flag the nodes in the set as coarse
  w(isn)=-100;
  % c=c U {i}
  c=[c isn];
  dim=dim+length(isn);
  
  indf=[];
  for ii=1:length(isn)
   i=isn(ii);
   % find nodes j such that i in S_j
   % neighbours of i
   %ineighb=cgml_neighb(a,i);
   %ineighb=cgml_setdiff(ineighb,[i]);
   ineighb=cgml_neighb1(aa,i);
   %[i ineighb]
   for jj=1:length(ineighb)
    j=ineighb(jj);
    %sj=find(s(j,:) > 0 & w > -50);
    sj=find(s(j,:));
    for kk=1:length(sj)
     k=sj(kk);
     if k == i & w(j) > -50 
      indf=[indf j];
      break
     end
    end % for k
   end % for j
  end % for i
  indf=cgml_unique(indf);
  
  f=[f indf];
  w(indf)=-50;
  dim=dim+length(indf);
  
  % remove isn and indf from the graph
  ind=[isn indf];
  for ii=1:length(ind)
   i=ind(ii);
   s(i,:)=0;
   s(:,i)=0;
  end
  
 end % if isn
   
end % while





