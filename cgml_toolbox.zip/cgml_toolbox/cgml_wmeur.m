function weight=cgml_wmeur(a,f,c,w);
%CGML_WMEUR computes the interpolation weights, Meurant's algorithm
%
% a matrix
% s influence matrix
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% WARNING : can compute negative weights !!!!
%
% Author G. Meurant
% Sept 2000
%

n=size(a,1);
weight=sparse(n,n);
mins=realmax;
maxs=realmin;

for ii=1:length(f)
 i=f(ii);
 % find the fine and coarse neighbours in a c_i, neighbours indi
 [ci,indi]=cgml_coarsno(a,w,i);
 % list of nodes we are interested in
 ind=indi;
 % set of fine neighbours
 fi=cgml_setdiff(indi,ci);
 lci=length(ci);
 if lci == 0
  error('CGML_WMEUR: no coarse neighbour in A')
 end
 
 % find the coarse neighbours of the fine neighbours of i
 for jj=1:length(fi)
  j=fi(jj);
  [cj,indj]=cgml_coarsno(a,w,j);
  % add cj to the list we are interested in but remove duplicates at the end
  ind=[ind cj];
 end % for j
 ind=unique(ind);
 
 % get the fine nodes
 indff=find(w(ind) == -50);
 indf=ind(indff);
 
 % get the coarse nodes
 indcc=find(w(ind) == -100);
 indc=ind(indcc);
 
 % add node i in first position
 indf=[i indf];
 
 mins=min(mins,length(indf)+length(indc));
 maxs=max(maxs,length(indf)+length(indc));
 % extract the fine-fine matrix
 bff=a(indf,indf);
 % extract the fine-coarse matrix
 bfc=a(indf,indc);
 % eliminate the fine nodes
 invff=inv(bff);
 % filter the inverse (remove small elements)
 invff=cgml_filmatr(invff,0.5);
 bc=-invff*bfc;
 % positive weights?
 %bc=abs(bc);
 % the weights are on the first row
 % normalize
 sum1=sum(full(bc(1,:)));
 if abs(sum1) > 1e-10
  weight(i,indc)=bc(1,:)/sum1;
 else
  weight(i,indc)=bc(1,:);
 end
end % for i

weight=sparse(weight);
p=[sort(f) sort(c)];
dimf=length(f);
wp=weight(p,p);
weight=wp(1:dimf,dimf+1:n);
%non_zero_weight=nnz(weight)
%size_loc_mat=[mins maxs]
 
