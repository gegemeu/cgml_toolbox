function ft=cgml_inters(f,t);
%CGML_INTERS  computes intersection of two lists of integers
% suppose no replications in lists
% use cgml_compr before if there are some
%
% Author G. Meurant
% Aug 2000
%

nt=length(t);
nf=length(f); 
if nt == 0 | nf == 0
 ft=[];
 return
end

if nf >= nt
 f1=f;
 n1=nf;
 f2=t;
 n2=nt;
else
 f1=t;
 n1=nt;
 f2=f;
 n2=nf;
end
ft=[];
for i=1:n1
 ind=find( f2 == f1(i));
 ft=[ft f2(ind)];
end