function [indi]=cgml_neighb1(s,i);
%CGML_NEIGHB1 find the neigbours for i in the graph of s
% assume s(i,i) = 0
%
% Author G. Meurant
% Aug 2000
%

%indi=find(abs(s(i,:)) > 0);
indi=find(s(i,:));



