function [indi]=cgml_neighbs(s,i);
%CGML_NEIGHBS find the neigbours for i in the graph of s
% assume s(i,i) = 0 and s symmetric
%
% Author G. Meurant
% Mar 2009
%

%indi=find(abs(s(i,:)) > 0);
indi=find(s(:,i))';



