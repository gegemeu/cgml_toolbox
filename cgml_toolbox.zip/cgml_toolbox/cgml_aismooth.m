function x=cgml_aismooth(a,z,d,b,x0,nu);
%CGML_AISMOOTH AINV Richardson smoothing for AMG
%
% nu iterations
% the preconditioner is M = Z D Z'
%
% Author G. Meurant
% Aug 2000
%

x=x0;

for i=1:nu
 x=x+z*(d.*(z'*(b-a*x)));
end

