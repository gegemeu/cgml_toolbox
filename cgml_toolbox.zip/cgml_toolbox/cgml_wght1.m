function [w,iw]=cgml_wght1(a);
%CGML_WGHT1 weights from the matrix a (approximate inverse)
% used by 'm2' coarsening algorithm
%
% Author G. Meurant
% Aug 2000
%

n=size(a,1);
b=abs(a);

% symmetric scaling of b
d=diag(1./sqrt(diag(b)));
bs=d*b*d;
b=sparse(bs-diag(diag(bs)));
w=zeros(1,n);
[w,iw]=max(b);
