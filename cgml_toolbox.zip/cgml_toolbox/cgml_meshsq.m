function [x,y]=cgml_meshsq(m);
%CGML_MESHSQ coordinates of an mxm mesh of the unit square
%
% Author G. Meurant
% Aug 2000
%

h=1/(m+1);
n=m^2;
xx=[h:h:1-h];
for i=1:m:n
 x(i:i+m-1)=xx;
end
for i=1:m
 y(i:m:n)=xx;
end
   
 