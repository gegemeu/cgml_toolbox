function w=cgml_wght_r(a,s);
%CGML_WGHT_R weights for the CLJP and PMIS algorithms
%
% a matrix of the problem, s influence matrix
%
% Author G. Meurant
% Mar 2009
%

n=size(a,1);
w=zeros(1,n);

rand('state',0);
randn('state',0)

for i=1:n
 % usual CLJP weights
 w(i)=nnz(s(:,i))+rand;
 % other possibility 
 %w(i)=nnz(s(:,i))+randn;
end

 
