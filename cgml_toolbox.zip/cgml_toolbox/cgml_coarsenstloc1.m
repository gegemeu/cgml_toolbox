function [f,c,w]=cgml_coarsenstloc1(a,s,w);
%CGML_COARSENSTLOC1 find the fine and coarse nodes standard AMG algorithm 
%
% s is an influence matrix 
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%  do not use the second pass
% some nodes may have already been defined
% difference with coarsenstloc is that it does not check for F-F connections
%
% author G. Meurant
% April 2002
%

f=find(w == -50);
c=find(w == -100);
n=size(s,1);
dim=length(f)+length(c);

% first pass of standard algo (see Wagner)
while dim < n
 % flas as Coarse the node with maximum weight
 [y,i]=max(w);
 w(i)=-100;
 % c=c U {i}
 c=[c i];
 dim=dim+1;
 
 % flag the influences of i as F points
 ind=find(s(:,i) > 0 & w' > -50);
 w(ind)=-50;
 dim=dim+length(ind);
 f=[f ind'];
 % find the points which influences the new F points
 % for all j in ind
 for j=ind'
   indk=find(s(:,j) >0 & w' > -50);
   % increase their weight
   w(indk)=w(indk)+1;
 end
 
 % decrease the weight of the points which are influenced by i
 ind=find(s(i,:) > 0 & w > -50);
 w(ind)=w(ind)-1;
end
dimf=length(f);



