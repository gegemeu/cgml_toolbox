function b=cgml_zerodd(k,a,nsd);
%CGML_ZERODD put to zero the components a(i) of vector a such that nsd(i)~=nsd(k) if nsd(k) and nsd(i) ~= 0
%
% Author G. Meurant
% June 2001
%

if nsd(k) > 0
 ind=find(nsd ~= nsd(k) & nsd > 0);
 b=a;
 m=size(ind,1);
 b(ind)=zeros(m,1);
else
 b=a;
end

