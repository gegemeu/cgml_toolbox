function [za,pa,zb,pb]=cgml_ainvn4(a,epssa,epssb,q);
%CGML_AINVN4 sparse approximate inverse of Benzi and Tuma (SISSC 97), computes two decompositions
%
% we keep only the q largest elements of each column
% return the inverse of the diagonal
%
% keep at least one non diagonal element to be able to use interpolation (not sure that it will always work)
% computes two decompositions, one with epssa and one with epssb
% this is needed by CGML_AINVMGINIT3
% not cheap computes both decompositions (could be done in one path instead)
%
% author G. Meurant,
% Aug 2000
%

n=size(a,1);
za=speye(n);
zb=speye(n);
pa=zeros(n,1);
pb=zeros(n,1);
anorm=epssa*max(abs(a'))'; % for dropping

% compute columnwise
for i=1:n-1
 xold=za(:,i);
 xold(i)=0;
 x=abs(za(1:i-1,i));
 if size(x,1) ~= 0
  ind=find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  za(ind,i)=0;
  [x,indx]=sort(abs(za(1:i-1,i)));
  qq=min(q,i-1);
  indl=indx(1:i-1-qq);
  za(indl,i)=0;
  x=abs(za(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal element
   [maxold,iold]=max(abs(xold));
   za(iold(1),i)=xold(iold(1));
  end
 end
 pa(i:n)=a(i,:)*za(:,i:n);
 p1=1/pa(i);
 indp=find(abs(pa(i+1:n)) > 0)+i;
 for j=indp'
  za(:,j)=za(:,j)-pa(j)*p1*za(:,i);
 end
end

% last column
xold=za(:,n);
xold(n)=0;
for j=1:n-1
 x=abs(za(j,n));
 if x < anorm(j) & x > 0
  za(j,n)=0;
 end
end
[x,indx]=sort(abs(za(1:n-1,n)));
qq=min(q,n-1);
indl=indx(1:n-1-qq);
za(indl,n)=0;
x=abs(za(:,n));
if nnz(x) == 1
 % keep the largest non diagonal element
 [maxold,iold]=max(abs(xold));
 za(iold(1),n)=xold(iold(1));
end
pa(n)=a(n,:)*za(:,n);
pa=1./pa;
nnz_a=nnz(za);

if epssa == epssb
 zb=za;
 pb=pa;
else
 % compute the second decomposition
 anorm=epssb*max(abs(a'))';
 
 for i=1:n-1
  xold=zb(:,i);
  xold(i)=0;
  x=abs(zb(1:i-1,i));
  if size(x,1) ~= 0
   ind=find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
   zb(ind,i)=0;
   [x,indx]=sort(abs(zb(1:i-1,i)));
   qq=min(q,i-1);
   indl=indx(1:i-1-qq);
   zb(indl,i)=0;
   x=abs(zb(:,i));
   if nnz(x) == 1
    % keep the largest non diagonal element
    [maxold,iold]=max(abs(xold));
    zb(iold(1),i)=xold(iold(1));
   end
  end
  pb(i:n)=a(i,:)*zb(:,i:n);
  p1=1/pb(i);
  indp=find(abs(pb(i+1:n)) > 0)+i;
  for j=indp'
   zb(:,j)=zb(:,j)-pb(j)*p1*zb(:,i);
  end
 end
 
 xold=zb(:,n);
 xold(n)=0;
 for j=1:n-1
  x=abs(zb(j,n));
  if x < anorm(j) & x > 0
   zb(j,n)=0;
  end
 end
 [x,indx]=sort(abs(zb(1:n-1,n)));
 qq=min(q,n-1);
 indl=indx(1:n-1-qq);
 zb(indl,n)=0;
 x=abs(zb(:,n));
 if nnz(x) == 1
  % keep the largest non diagonal element
  [maxold,iold]=max(abs(xold));
  zb(iold(1),n)=xold(iold(1));
 end
 pb(n)=a(n,:)*zb(:,n);
 pb=1./pb;
 nnz_b=nnz(zb);
end
