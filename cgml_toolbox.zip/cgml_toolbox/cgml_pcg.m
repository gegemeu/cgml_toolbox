function [x,nit,res,trueres,gest,agest]=cgml_pcg(a,b,x0,epss,nitmax,truer,scaling,tb,iprint,precond,varargin);
%CGML_PCG preconditioned conjugate gradient for a matrix a with different preconditioners
% with also block preconditioners, block size tb
% this is a reliable implementation of PCG
% with  bounds of the A-norm of the error
%
%
% input: (see CGML_README for more details)
% a - matrix
% b - right hand side
% x0 - starting vector,
% epss - threshold for stopping criterion
% (stop if norm(r^k)<= epss norm(r^0) or nit > nitmax
% nitmax - maximum number of iterations
% iprint = 1 print results
% precond - type of preconditioning
%  ='no' M=I
%  ='sc' diagonal
%  ='ic' IC(0)
%  ='ch' IC(epsilon)
%  ='lv' IC(level)
%  ='sh' shifted alg of Manteuffel using levels
%  ='ss' SSOR with omega=1
%  ='po' least square polynomial
%  ='ai' AINV
%  ='sa' SAINV
%  ='tw' Tang and Wan approximate inverse
%  ='ml' multilevel
%  ='mb' block AMG
%  ='dd' multilevel with domain decomposition ordering
% param=varargin(1) - parameter needed by some preconditioners
%  = nothing for 'no', 'ss' and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv' and 'ei'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = nothing for 'tw'
%  = number of levels for 'ml' and 'dd'
% the other parameters for 'ml' and 'dd' are in varargin
%  lmax = max number of levels
%  nu = number of smoothing steps
%  almax = parameter alpha
%  alb = parameter alpha for the generation of grids with AINV
%  smooth = type of smoothing operator
%  influ = type of influence matrix
%  coarse = type of coarsening algorithm
%  interpo = type of interpolation algorithm
% this is a special case that cannot be handled like the other ones
% for 'dd' same +
% metpar = algorithm for the partitioning of the graph
%  = 'r' for reverse Cuthill-McKee (RCM)
%  = 's' for the spectral partitioning
%  = 'i' for geometric partitioning
% levels = the number of subdomains is 2^levels
% metnum = reordering algorithm of the subdomains
%  = 'md' for minimum degree
%  = 'rc' for RCM
%
% output:
% res - l_2 norm of computed residual
% gest - lower bound on the A norm of the error
% agest - anti Gauss estimate of the A norm of the error
% x - approximate solution
% nit - number of iterations
%
% Author G. Meurant
% March 2001 modified Feb 2009
%

%tic

n=size(a,1);

if nargin == 10
 param=[];
else
 param=varargin{1};
end

% parameters for the multilevel methods
if precond == 'ml' | precond == 'mb'
 % get the input parameters for the multilevel method
 if nargin < 18
  error('CGML_PCG: some parameters are not defined for ML')
 end
 
 lmax=param;
 nu=varargin{2};
 almax=varargin{3};
 alb=varargin{4};
 smooth=varargin{5};
 influ=varargin{6};
 coarse=varargin{7};
 interpo=varargin{8};
 gama=1;
 falp=1;
 qmin=n;
 alq=1;
 normal=0;
 xin=zeros(n,1);
elseif precond == 'dd'
 % get the input parameters for the multilevel method
  if nargin < 21
  error('CGML_PCG: some parameters are not defined for DD')
  end
 
 lmax=param;
 nu=varargin{2};
 almax=varargin{3};
 alb=varargin{4};
 smooth=varargin{5};
 influ=varargin{6};
 coarse=varargin{7};
 interpo=varargin{8};
 metpar=varargin{9};
 levels=varargin{10};
 metnum=varargin{11};
 gama=1;
 falp=1;
 qmin=n;
 alq=1;
 normal=0;
 xin=zeros(n,1);
end

% max number of non zeros per row
nnp=cgml_maxnzpr(a);

% for robustness we eventually symmetrically scale the matrix
if scaling ==1
 a_old=a;
 b_old=b;
 [a,dda]=cgml_normaliz(a);
 b=dda.*b;
 nd=max(1./dda);
else
 dda=ones(n,1);
 nd=1;
end

% norm of the "true" residual
trueres=[];

% initial vector
x=x0;
r=b-a*x;

% init of preconditioners
if iprint >= 1
 disp(' ')
 str=sprintf(' Preconditioner: %s',precond);
 disp(str)
end

if precond ~= 'ml' & precond ~= 'mb' & precond ~= 'dd'
 % block and point preconditioners
 [dd,l,d1,ld]=cgml_initprecb(a,precond,tb,iprint,param);
elseif precond == 'ml'
 % multilevel preconditioner
 % rename as cgml_amginit
 [ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,czb,cdb,cl,cda,lmax,err]=cgml_amginit3(a,almax,alb,lmax,falp,qmin,alq,smooth,influ,coarse,interpo,normal,iprint);
 if err == 1
  error('*********ERROR in AMGINIT3')
 end
 l=speye(n);
 dd=ones(n,1);
 d1=dd;
 ld=1;
 
elseif precond == 'mb'
 % multilevel block preconditioner
 % rename as cgml_amgbinit
 [ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,czb,cdb,cl,cda,lmax,err]=cgml_amginit3b(a,almax,alb,lmax,falp,qmin,alq,smooth,influ,coarse,interpo,normal,tb,iprint);
 if err == 1
  error('*********ERROR in AMGINIT3B')
 end
 l=speye(n);
 dd=ones(n,1);
 d1=dd;
 ld=1;
 
elseif precond == 'dd'
 % multilevel preconditioner with domain decomposition ordering
 parta=0;
 if parta == 0
 % generate the influence matrix
 sa=cgml_cinflu4dd(a,almax,alb,lmax,falp,qmin,alq,smooth,influ,coarse,interpo,iprint);
 else
  sa=a;
 end
 % partition the graph of the matrix or the influence matrix
 if metpar ~= 'i'
  [maps, perm, nbnodes, CCgraph] = cgml_recursiv_decoup(levels,sa,metpar,metnum,iprint);
 else
  % geometric partitioning (needs the coordinates xy)
  % assume we are in the unit square
  msq=fix(sqrt(n));
  if msq^2 == n
   [xx,yy]=cgml_meshsq(msq);
   xy(:,1)=xx(:); xy(:,2)=yy(:);
   [maps, perm, nbnodes, CCgraph] = cgml_recursiv_decoup(levels,sa,metpar,metnum,iprint,xy);
  else
   error('CGML_PCG: cannot use geometric partitioning when the domain is not the unit square');
  end
 end

 % invert the permutation which was sent back
 ip=cgml_invperm(perm);
 % permute the matrix a, the right hand side b and the initial vector
 nsd(ip)=maps;
 a=a(perm,perm);
 b=b(perm);
 x0=x0(perm);

 % init
 x=x0;
 % initial residual
 r=b-a*x;
 % init of matrices on all levels
 [ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,czb,cdb,cl,cda,lmax,err]=cgml_amginit4dd(a,almax,alb,lmax,falp,qmin,alq,smooth,influ,coarse,interpo,normal,nsd,perm,metpar,levels,iprint);
 if err == 1
  error('*********ERROR in AMGINIT4DD')
 end
 l=speye(n);
 dd=ones(n,1);
 d1=dd;
 ld=1;
end
% end of construction of preconditioners

if iprint >= 1
 sl=nnz(l);
 sd=length(dd);
 str=sprintf('storage for l = %g',sl);
 str1=sprintf(' storage for d =%g',sd);
 disp(' ')
 disp([str str1])
 disp(' ')
end

% solve of M z = r
if precond ~= 'ml' & precond ~= 'mb'  & precond ~= 'dd'
 z=cgml_solveprecb(r,a,dd,l,precond,tb,param);
elseif precond == 'mb'
 % multilevel block preconditioner
 z=cgml_amgit3b(a,r,xin,nu,1,ca,cm,cp,cr,cperm,ciperm,cdf,czb,cdb,cl,cda,lmax,smooth,gama,normal,tb);
elseif precond == 'ml' | precond == 'dd'
 % multilevel preconditioner
 z=cgml_amgit3(a,r,xin,nu,1,ca,cm,cp,cr,cperm,ciperm,cdf,czb,cdb,cl,cda,lmax,smooth,gama,normal);
end

p=z;
nit=0;
r0=r'*r;
rtr=z'*r;
r00=rtr;
% init for estimation of error
alp1=1;
bet1=0;
gam2=1;
c2=1;
% we compute the estimates delay iterations back
% must be put as an argument
delay=1;
%delay=10
if iprint == 1
 str=sprintf('initial residual = %g',sqrt(r0));
 disp(str)
end
eps2=epss*epss;
resid=realmax;

% iterations
while resid >= eps2*r0 & nit < nitmax
 nit=nit+1;
 ap=a*p;
 alp=rtr/(p'*ap);
 % estimates of error
 om=1./alp+bet1/alp1;
 t(nit,nit)=om;
 if nit == 1
  told(1)=1./om;
  d=om;
 else
  c2=c2*gam2/d^2;
  dold=d;
  d=om-gam2/d;
  tnew=c2/d;
  dp=d-gam2/dold;
  % anti gauss estimate
  ag=2*c2/dp;
  if nit < delay
   told(nit)=tnew;
  else
   told(delay)=tnew;
  end
 end

 alp1=alp;
 x=x+alp*p;

 % computed residual
 r=r-alp*ap;

 % solve of M z = r
 if precond ~= 'ml' & precond ~= 'mb'  & precond ~= 'dd'
  z=cgml_solveprecb(r,a,dd,l,precond,tb,param);
 elseif precond == 'mb'
  z=cgml_amgit3b(a,r,xin,nu,1,ca,cm,cp,cr,cperm,ciperm,cdf,czb,cdb,cl,cda,lmax,smooth,gama,normal,tb);
 elseif precond == 'ml' | precond == 'dd'
  %multilevel preconditioner
  z=cgml_amgit3(a,r,xin,nu,1,ca,cm,cp,cr,cperm,ciperm,cdf,czb,cdb,cl,cda,lmax,smooth,gama,normal);
 end

 rtrz=z'*r;
 rk=r'*r;
 resid=rk;

 % "true" residual norm
 if truer == 1
  trueres(nit)=norm(b-a*x);
 end

 % residual l_2 norm
 res(nit)=sqrt(rk);

 bet=rtrz/rtr;
 beta(nit)=bet;
 rtr=rtrz;

 % estimates of A-norm of the error
 gam2=bet/alp^2;
 gam=sqrt(gam2);
 t(nit,nit+1)=gam;
 t(nit+1,nit)=gam;
 t=sparse(t);
 % gest  = lower Gauss bound
 % agest = anti-Gauss estimate
 if nit > max([delay 1])
  est=sum(told(1:delay));
  gest(nit-delay)=sqrt(r00*est);
  if ag+est > 0
   agest(nit-delay)=sqrt(r00*(ag+est));
  else
   agest(nit-delay)=gest(nit-delay);
  end
  if iprint == 2
   str=sprintf(' estimate of A norm at it %g',nit-delay);
   str1=sprintf(' = %g',gest(nit-delay));
   str2=sprintf(' ag = %g',agest(nit-delay));
   disp([str str1 str2])
  end
 end
 if nit >= delay
  temp=told(2:delay);
  told(1:delay-1)=temp;
 end

 bet1=bet;
 p=z+bet*p;

 % output
 if iprint == 2
  str1=sprintf('nit = %g',nit);
  str2=sprintf(' res = %g',res(nit));
  disp([str1 str2])
 end

end

if iprint >= 1
 disp('------------------------')
 str1=sprintf(' preconditioner: %s %g',precond,param);
 disp(str1)
 str1=sprintf('  number of iterations = %g',nit);
 disp(str1)
 trueresi=norm(b-a*x);
 disp(' ')
 str=sprintf('  storage for l = %g',sl);
 str1=sprintf('  storage for d = %g',sd);
 disp([str str1])
 str=sprintf('  norm of true res = %g',trueresi);
 disp(' ')
 disp([str])
 str3=sprintf('  nr/nr0 = %g',sqrt(resid/r0));
 disp(' ')
 disp(str3)
end

if precond == 'dd'
 % permute the solution back
 x=x(ip);
end

% if scaling go back to the solution of the original system
if scaling == 1
 x=dda.*x;
 trueresi=norm(b_old-a_old*x);

 if iprint >= 1
  disp('---We are back to the original scale')
  str=sprintf(' norm of true res for x = %g',trueresi);
  disp(' ')
  disp(str)
  str3=sprintf(' nr/nr0 = %g',sqrt(resid/r0));
  disp(' ')
  disp(str3)
 end
end

%toc
