function [lmin,lmax]=cgml_gerschgo(a);
%CGML_GERSCHGO  computes the Gerschgorin bounds for a matrix a
%
% Author G. Meurant
%

n=size(a,1);
un=ones(n,1);
aa=abs(a);
aa=spdiags(zeros(n,1),0,aa);
b=abs(diag(a));
bb=aa*un;
lmin=min(b-bb);
lmax=max(b+bb);
