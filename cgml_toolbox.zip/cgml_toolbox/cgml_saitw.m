function m=cgml_saitw(a,k,l);
%CGML_SAITW  Sparse approximate inverse of Tang ang Wan
% k and l defines the neighboring sets that are used for
% solving the least squares problems
%
% Author G. Meurant
% Sept 2000
%

n=size(a,1);
m=sparse(n,n);

% solve a least squares problem for each row of m
for i=1:n
 % compute the neighboring sets of degree k and l
 indk=cgml_neighbset(a,i,k);
 indl=cgml_neighbset(a,i,l);
 
 % extract the matrix
 akl=a(indk,indl);
 aklt=akl';
 se=size(aklt,1);
 
 % rhs zero everywhere except for i
 rhs=zeros(se,1);
 ii=find( indl == i);
 rhs(ii)=1;
 
 % solve the normal equation to solve the least squares problems
 mi=(akl*aklt)\(akl*rhs);
 % this is line i of the approximate inverse
 m(i,indk)=mi';
end

% symmetrize
m=0.5*(m+m');
