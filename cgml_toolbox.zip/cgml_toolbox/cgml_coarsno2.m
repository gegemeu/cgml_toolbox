function [ci,fi,indi,diw]=cgml_coarsno2(a,s,w,i);
%CGML_COARSENO2 find the coarse, fine nodes and neigbours of i in s
% w = -100 for coarse nodes
% assume the diagonal is zero
%
% Author G. Meurant
% Aug 2000
%

% neighbours
indi=find(s(i,:));
wi=w(indi);
ci=indi(wi == -100);
fi=indi(wi > -100);
diw=find(a(i,:) & (s(i,:) == 0));


