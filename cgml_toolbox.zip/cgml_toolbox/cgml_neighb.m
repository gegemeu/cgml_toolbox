function [indi]=cgml_neighb(s,i);
%CGML_NEIGHB find the neigbours for i in the graph of s
%
% Author G. Meurant
% Aug 2000
%

%indi=find(abs(s(i,:)) > 0);
indi=find(s(i,:));
%indi=cgml_fmt(indi,i);
indi=cgml_setdiff(indi,i);
%if length(indi) == 0
% indi=[];
%end


