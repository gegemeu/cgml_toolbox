function x=cgml_icsmooth(a,l,d,b,x0,nu);
%CGML_ICSMOOTH  Richardson smoothing with IC for AMG
%
% nu iterations
% the preconditioner is L D^-1 L^T
%
% Author G. Meurant
% Aug 2000
%

x=x0;
lt=l';

for i=1:nu
 y=b-a*x;
 z=l\y;
 y=lt\(d.*z);
 x=x+y;
end

