function [maps, perm, nbnodes, CCgraph] = cgml_recursiv_decoup(levels,A,met,rfill,iprint,xy)
%CGML_RECURSIVE_DECOUP recursive splitting with partitioning
%
%			recursive splitting with front partitioning (giving A only)
%			or inertial partitioning (giving also xy)
%
% Input:
%			levels: number of SD will be 2^levels
%			A : the graph matrix (nodes connectivity)
%			(optionnal) xy: the nodes coordinates (geometry)
%
% Output:
%			maps: for each node i, maps(i) gives its subdomain number (1 to 2^levels)
%					- 0 if node separator
%			perm: permutation numbering - subdomains first, separators at the end
%              with fill-in reduction due to call to sd_reorder
%			nbnodes(1:2^levels+1): the number of nodes in each subdomain or separator
%			CCgraph: diag matrix giving the number of nodes in each
%						Connected Component of the subdomains
%
% From P. Leca
% May 2001
%

switch met

 case 'r'
  % Reverse Cuthill-McKee partitioning
  method='cgml_rcmpart';

 case 's'
  % spectral partitioning
  method='cgml_specpart';

 case 'i'
  % geometric partitioning
  method='cgml_inertpart';
end

if met == 'r' | met == 's'
 if iprint > 1
  disp('splitting without coordinates');
 end
 [maps] = cgml_dice_with_node_sep(method,levels,A);
 
elseif met == 'i'
 if iprint > 1
  disp('splitting with coordinates');
 end
 [maps] = cgml_dice_with_node_sep(method,levels,A,xy);
 
else
 error('CGML_RECURSIVE_DECOUP: wrong method')
end
 
sep = find(maps < 0);
maps = maps + 1;
maps(sep) = 0;
perm = [];
 
numsd = 2^levels;
nbnodes = zeros(numsd+1,1);

% loop on the number of sub domains
for isd = 1:numsd
 sd_isd = find(maps == isd);
 nbnodes(isd) = size(sd_isd,2);
 perm = [perm, sd_isd];
end
[ddo] = cgml_sd_reorder(A,perm,sep,numsd,nbnodes,rfill);
nbnodes(numsd+1) = size(sep,2);

% verification
[CC,CCgraph] = cgml_components(A(perm,perm));
 
perm = ddo;

