function weight=cgml_winterp(a,s,f,c,w);
%CGML_WINTERP computes the interpolation weights, standard AMG interpolation
%
% s is an influence matrix computed by influ
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% Author G. Meurant
% Aug 2000
%

n=size(a,1);
d=zeros(n,1);
weight=sparse(n,n);
aa=a-diag(diag(a));

for ii=1:length(f)
 i=f(ii);
 % coarse nodes c_i, neighbours indi
 [cia,india]=cgml_coarsno1(aa,w,i);
 if isempty(cia)
  error('CGML_WINTERP: no coarse neighbour in A')
 end
 %[ci,indi]=cgml_coarsno1(s,w,i);
 % dis=cgml_setdiff(indi,ci)
 % diw weak neighbours in A (need the neighbours of i in inda)
 [ci,dis,indi,diw]=cgml_coarsno2(aa,s,w,i);
 % ci = C inter S_i
 if isempty(ci)
  %disp('CGML_WINTERP:  no coarse neighbour in S')
  ci=cia;
  indi=india;
 end
 
 % compute d_i and d_j
 d(i)=a(i,i)+sum(a(i,diw));
 d(ci)=a(i,ci);
 for kk=1:length(dis)
  k=dis(kk);
  % compute dj
  suma=sum(a(k,ci));
  if suma ~= 0
   d(ci)=d(ci)+a(i,k)*a(k,ci)'/suma;
  end
 end
 weight(i,ci)=-d(ci)'/d(i);
end

weight=sparse(weight);
p=[sort(f) sort(c)];
dimf=length(f);
wp=weight(p,p);
weight=wp(1:dimf,dimf+1:n);
%nnz(weight)



