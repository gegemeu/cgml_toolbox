function prol=cgml_enermin(a,f,c);
%CGML_ENERMIN computes the energy minimizing interpolation
%
% see Wan's PhD thesis
% very primitive coding not cost efficient
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% Author G. Meurant
% Aug 2000
%

n=size(a,1);
m=length(c);
 
% q has m diagonal blocks of size n x n stored in a cell array
% bt is made of diagonal matrices stored in vectors
l=0;
hai=speye(n,n);
zer=zeros(n,1);

for i=sort(c)
 l=l+1;
 ai=hai;
 indi=cgml_neighb(a,i);
 indi=[i indi];
 avois=a(indi,indi);
 ai(indi,indi)=avois;
 iq(l)={inv(ai)};
 ii=zer;
 ii(indi)=ones(length(indi),1);
 bt(l)={ii};
end

% solution phase
% solve for the Lagrange multiplier, see Wan's PhD thesis
bqb=sparse(n,n);
l=0;
for i=sort(c)
 l=l+1;
 ii=spdiags(bt{l},0,n,n);
 bqb=bqb+ii*iq{l}*ii;
end
b=-ones(n,1);
lamb=bqb\b;

% solve for the weights column by column
l=0;
for i=sort(c)
 l=l+1;
 phi=-iq{l}*(bt{l}.*lamb);
 prol(:,l)=phi;
 prol=sparse(prol);
end
prol=sparse(prol);




 