function x=cgml_sgssmooth(a,dl,b,x0,nu);
%CGML_SGSSMOOTH symmetric Gauss Seidel smoothing for AMG
%
% nu iterations starting from x0
% dl contains the lower triangular part of a
%
% Author G. Meurant
% Aug 2000
%

x=x0;
lt=triu(a,1);
dlt=dl';
l=tril(a,-1);

for i=1:nu
 x=dl\(b-lt*x);
 x=dlt\(b-l*x);
end


