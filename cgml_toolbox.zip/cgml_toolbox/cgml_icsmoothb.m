function x=cgml_icsmoothb(a,l,d,b,x0,nu);
%CGML_ICSMOOTHB  Richardson smoothing with block IC
%
% nu iterations
% the preconditioner is L D L^T
%
% Author G. Meurant
% Aug 2006
%

x=x0;
lt=l';

for i=1:nu
 y=b-a*x;
 z=l\y;
 zz=d\z;
 y=lt\zz;
 x=x+y;
end

