function [ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,czb,cdb,cl,cda,lmax,err]=cgml_amginit4dd(a,alpmax,alb,lmax,falp,qmin,alq,smooth,infl,coarse,interpo,normal,nsd,perm,metpar,levels,iprint);
%CGML_AMGINIT4DD init of multi level iteration with domain decomposition ordering
%
% f and c are the fine and coarse nodes
% l=1 fine grid, l=lmax coarsest grid
%

% Input:
%  matrix = a, rhs = b, init vector = x0,
%  stop crit = epss
%  truncation coeff = almax for the grid and alb for smoothing
%  max nb levels = lmax
%  smoother = smooth, influence type = influ, coarsening type = coarse
%  interpolation: interpo
%  gama=1 V-cycle, gama=2 W-cycle
%  smooth = smoother
%  infl = mode of computation of the influence matrix
%  coarse = coarsening algorithm
%  interpo = interpolation algorithm
%  normalization = normal
%  print level = iprint
%  nsd = subdomain number or 0 (interfaces) and -1 (corner points)
%
% Output:
%  matrices for each level in cell arrays
%  ca = matrix on level l
%  cm = preconditioner on level l
%  cp = prolongation on level l
%  cr = restriction on level l
%  cperm = permutation on level l
%  ciperm = inverse permutation on level l
%  cdf = number of fine nodes on level l
%  cz = factor of the AINV decomposition on level l (coarsening)
%  cd = diagonal factor of the AINV dec on level l (coarsening)
%  czb = factor of the AINV decomposition on level l (smoothing)
%  cdb = diagonal factor of the AINV dec on level l (smoothing)
%  cl = Cholesky factor (for the coarsest level only)
%
% author G. Meurant
% Aug 2000
%

addn=1; %  = 0 do not add the neighbours to the interface (not for 'si')

if strcmp(coarse,'so')

 if metpar ~= 'i'
  [perm1,nbnodes1,numsd,overlap,nSD,nbSD] = cgml_recursiv_decoup_overlap(levels,1,a,metpar,iprint);

 else
  xy=gmesh(sqrt(n));
  [perm1,nbnodes1,numsd,overlap,nSD,nbSD] = cgml_recursiv_decoup_overlap(levels,1,a,metpar,iprint,xy);
 end %if

 iSDnodes=zeros(1,size(a,1));
 % pointers on subdomains
 pointer = zeros(numsd,1);
 pointer(1) = 0;
 for i = 2:numsd+1
  pointer(i) = pointer(i-1) + nbnodes1(i-1);
  iSDnodes(pointer(i-1)+1:pointer(i))=i-1;
 end % for
end % if coarse

nbsd=2^levels;
numsd=nbsd;
a_old=a;
cnsd=nsd;

if normal == 1
 [ad,da]=cgml_normaliz(a);
 cda(1)={da};
else
 cda(1)={[]};
end

err=0;
done=0;
alp=alpmax;
alpb=alb;
q=qmin;
nmax=size(a,1);
nnza=nnz(a);
% estimate of the condition number of A with Lanczos (50 it)
%[lmin,lmaxx,se]=lancz(a,50);
%kap=lmaxx/lmin
%
totstr=nnza;
tota=totstr;
totpt=nmax;
% exact solve if less than nmin nodes
nmin=9;

% start going down the levels
l=0;
nnold=size(a,1);

while done == 0
 n=size(a,1);

 if n <= nmin | l == lmax
  % coarsest level
  if iprint >= 1
   disp(' ')
   disp('CGML_AMGINIT4DD: stop the recursion')
   disp('--------------------')
   disp(' ')
  end
  lmax=l;
  caa=ca{l-1};
  % compute Cholesky decomposition for the exact solve
  r=chol(caa);
  cl(l)={r};
  if iprint >= 1
   disp(' ')
   str=sprintf('number of levels = %g',lmax);
   disp(str)
  end
  break
 end

 % go down to the next level
 l=l+1;

 % modification to truncate on all levels except the fine one
 %if l == 1
 % q=nmax;
 %else
 % q=qmin;
 %end

 % initialize the cell arrays
 cf(l)={[]};
 cc(l)={[]};
 cw(l)={[]};
 cdf(l)={[]};
 cz(l)={[]};
 cd(l)={[]};
 cp(l)={[]};
 ca(l)={[]};
 cm(l)={[]};
 cl(l)={[]};
 czb(l)={[]};
 cdb(l)={[]};
 cda(l+1)={[]};
 cnosd(l)={cnsd};
 zb=[];
 pb=[];

 nz_of_A=nnz(a);
 if iprint >= 1
  str=sprintf('level = %g',l);
  str1=sprintf(', n = %g',n);
  str2=sprintf(' nb of non zero entries = %g',nz_of_A);
  disp(' ')
  disp(['----------------- ' str str1])
  disp(str2)
  str=sprintf(' Smoother = %s',smooth);
  disp(str)
 end

 if strcmp(smooth,'ai') | strcmp(smooth,'cg')
  % AINV smoother or preconditoner for CG smoother
  % AINV factorization, keep only the q largest elements
  [za,pa,zb,pb]=cgml_ainvn4(a,alp,alpb,q);
  nnna(l)=nnz(a);
  nnnz(l)=nnz(za);
  if nnz(find(pa<0)) ~= 0
   error('CGML_AMGINIT4DD: non positive definite matrix')
  end % if nnz
  % store the AINV factorizations
  cz(l)={za};
  cd(l)={pa};
  czb(l)={zb};
  cdb(l)={pb};
  % compute the preconditioner M = Z P Z'
  %m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  m=speye(n);
  cm(l)={m};

 elseif strcmp(smooth,'ad')
  % AINV factorization, keep only the q largest elements
  [za,pa,zb,pb]=cgml_ainvn4dd1(a,alp,alpb,q,cnsd,nbsd);
  nnna(l)=nnz(a);
  nnnz(l)=nnz(za);
  if nnz(find(pa<0)) ~= 0
   error('CGML_AMGINIT4DD: non positive definite matrix on level')
  end
  % store the AINV factorizations
  cz(l)={za};
  cd(l)={pa};
  czb(l)={zb};
  cdb(l)={pb};
  % compute the preconditioner M = Z P Z'
  %m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  m=speye(n);
  cm(l)={m};

 elseif strcmp(smooth,'sa')
  % SAINV factorization, keep only the q largest elements
  [za,pa,zb,pb]=cgml_sainvn4(a,alp,alpb,q);
  nnna(l)=nnz(a);
  nnnz(l)=nnz(za);
  if nnz(find(pa<0)) ~= 0
   error('AINVMGINIT4DD: non positive definite matrix')
  end
  % store the AINV factorizations
  cz(l)={za};
  cd(l)={pa};
  czb(l)={zb};
  cdb(l)={pb};
  % compute the preconditioner M = Z P Z'
  %m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  m=speye(n);
  cm(l)={m};

 elseif strcmp(smooth,'sd')
  % SAINV factorization, keep only the q largest elements
  [za,pa,zb,pb]=cgml_sainvn4dd(a,alp,alpb,q,cnsd);
  nnna(l)=nnz(a);
  nnnz(l)=nnz(za);
  if nnz(find(pa<0)) ~= 0
   error('CGML_AMGINIT4DD: non positive definite matrix on level')
  end
  % store the AINV factorizations
  cz(l)={za};
  cd(l)={pa};
  czb(l)={zb};
  cdb(l)={pb};
  % compute the preconditioner M = Z P Z'
  %m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  m=speye(n);
  cm(l)={m};

 elseif strcmp(smooth,'tw')
  disp('saitw smoothing')
  m=cgml_saitw(a,0,1);
  cm(l)={m};
  cz(l)={m};
  cd(l)={m};
  czb(l)={m};
  cdb(l)={m};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(m);
  za=m;
  zap=m;
  spa=m;

 elseif strcmp(smooth,'po')
  % polynomial smoothing
  [lmi,lma]=cgml_gerschgo(a);
  lmi=max(0,lmi);
  degpol=1;
  m=cgml_setmcarre(degpol,lmi,lma);
  cm(l)={m};
  czb(l)={lmi};
  cdb(l)={lma};
  cz(l)={a};
  cd(l)={a};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(a);
  za=a;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'gs') | strcmp(smooth,'ga')
  % Symmetric Gauss-Seidel smoother
  tl=tril(a);
  tu=triu(a);
  % store the smoother
  cz(l)={tl};
  cd(l)={tu};
  czb(l)={tl};
  cdb(l)={tu};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   im=tl*diag(1./diag(a))*tl';
   m=inv(im);
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=0;
  za=tl;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'ic')
  % Incomplete Cholesky smoother
  % IC(0) of a general matrix
  [dd,ll]=cgml_chicopt(a);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'id')
  % Incomplete Cholesky smoother dd ordering
  % IC(0) of a general matrix
  [dd,ll]=cgml_chicoptdd(a,cnsd);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'ch')
  % Incomplete Cholesky with fill
  % IC(epsilon) of a general matrix
  [dd,ll]=cgml_chepsopt(a,alb);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'cd')
  % Incomplete Cholesky with fill dd ordering
  % IC(epsilon) of a general matrix
  [dd,ll]=cgml_chepsoptdd(a,alb,cnsd);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'lv')
  % Incomplete Cholesky with level
  % IC(level) of a general matrix
  [dd,ll]=cgml_chlevopt(a,alb);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'sh')
  % Incomplete Cholesky of Manteuffel with shift and level
  % IC(level) of a general matrix
  % 3 retries
  [lu,bdown]=cgml_miluk(a,alb,3);
  ll=tril(lu);
  dd=diag(ll);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT4DD: Pb with incomplete factorization')
  end
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;

 elseif strcmp(smooth,'gc')
  % CG with diagonal preconditioner smoother
  dd=1./diag(a);
  cd(l)={dd};
  cz(l)={a};
  za=a;
  cz(l)={za};
  czb(l)={za};
  cdb(l)={dd};
  nnna(l)=nnz(a);
  nnnz(l)=0;
  m=a;
  cm(l)={a};
  zap=a;
  spa=a;

 elseif strcmp(smooth,'bj')
  % tridiagonal smoother
  % corresponds to Block Jacobi for a rectangular mesh
  dd=diag(diag(a,0),0)+diag(diag(a,-1),-1)+diag(diag(a,1),1);
  cd(l)={dd};
  cz(l)={a};
  za=a;
  cz(l)={za};
  czb(l)={dd};
  cdb(l)={dd};
  nnna(l)=nnz(a);
  nnnz(l)=0;
  m=a;
  cm(l)={a};
  zap=a;
  spa=a;

 else
  error('CGML_AMGINIT4DD: smoother not implemented')
 end

 % smoothing operator (for 'wi' interpolation)
 if strcmp(interpo,'wi')
  sm=speye(n,n)-m*a;
 end
 %
 % influence matrix

 if strcmp(infl,'b')
  % same as 'a' except keeps at least one element per row
  s=cgml_influstb(a,alp);

 elseif strcmp(infl,'a')
  % corresponds to 'a': standard algorithm using A
  % and the strong connections defined by alpha
  s=cgml_influst(a,alp);
  
 elseif strcmp(infl,'m')
  % use M to define the coarse grid
  if exist('m')
   s=cgml_influm(m);
  else
   error('CGML_AMGINIT4DD: M is not defined with this smoother')
  end

 elseif strcmp(infl,'mi')
  % variants of M (when there is not enough coarse nodes)
  % better to use 2 values of alpha
  if exist('m')
   s=cgml_influin(a,m,alp);
  else
   error('CGML_AMGINIT4DD: M is not defined with this smoother')
  end


 elseif strcmp(infl,'mc')
  if exist('m')
   s=cgml_influ(m,alp);
  else
   error('CGML_AMGINIT4DD: M is not defined with this smoother')
  end

 elseif strcmp(infl,'mt')
  if exist('m')
   s=cgml_influmt(m);
  else
   error('CGML_AMGINIT4DD: M is not defined with this smoother')
  end


 elseif strcmp(infl,'z')
  % use Z to define the coarse grid
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influm(zzt);
  else
   error('CGML_AMGINIT4DD: Z is not defined with this smoother')
  end

 elseif strcmp(infl,'zc')
  % variants of Z
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influ(zzt,alp);
  else
   error('CGML_AMGINIT4DD: Z is not defined with this smoother')
  end

 elseif strcmp(infl,'zi')
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influin(a,zzt,alp);
  else
   error('CGML_AMGINIT4DD: Z is not defined with this smoother')
  end

 elseif strcmp(infl,'zt')
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influmt(zzt);
  else
   error('CGML_AMGINIT4DD: Z is not defined with this smoother')
  end

 elseif strcmp(infl,'o')
  % do nothing the influence matrix is computed in the
  % coarsening step, dd with interface
  s=speye(n);
  
 else
  error('CGML_AMGINIT4DD: this influence algorithm does not exist')
 end
 cs(l)={s};

 % modify the values of parameters for next level
 alp=falp*alp;
 alpb=falp*alpb;
 q=fix(alq*q);

 % if there is nothing in S or Z is diagonal
 % go up one level and stop the coarsening process
 if nnz(s) == 0 | nnz(za) == size(za,1)
  if iprint >= 1
   disp('CGML_AMGINIT4DD: Pb S is empty or Z is diagonal')
  end
  [nnz(s) nnz(za)]
  % go up one level and stop
  if l == 1
   error('CGML_AMGINIT4DD: cannot go back on level 1')
  else % if l
   lmax=l-1;
  end % if l
  % need to compute the Cholesky decomposition of the last matrix
  caa=ca{l-2};
  r=chol(caa);
  cl(lmax)={r};
  if iprint >= 1
   disp(' ')
   str=sprintf('after correction final number of levels = %g',lmax);
   disp(str)
  end
  break % while done
 end % if nnz

 % construction of coarse mesh

 if strcmp(coarse,'st')
  % standard algorithm
  [f,c,w]=cgml_coarsenstnew(a,s);
  
 elseif strcmp(coarse,'cl')
  % (modified) CLJP algorithm
  [f,c,w]=cgml_coarsencljp(a,s);
  
 elseif strcmp(coarse,'pm')
  % PMIS algorithm
  [f,c,w]=cgml_coarsenpmis(a,s);
  
 elseif strcmp(coarse,'hm')
  % HMIS algorithm
  [f,c,w]=cgml_coarsenhmis(a,s);
  
 elseif strcmp(coarse,'fa')
  % (modified) CLJP algorithm
  [f,c,w]=cgml_coarsenfalg(a,s);

  %elseif coarse == 'si'
  % [f,c,w]=cgml_coarsenstnewdd(a,s,cnsd,l);

 elseif strcmp(coarse,'mz')
  % standard algorithm + check of neighbours in a
  if ~exist('m')
   m=speye(n,n);
  end
  [f,c,w]=cgml_coarsenstmz(a,m,s);

 elseif strcmp(coarse,'n1')
  % standard algorithm + add node using Brandt's ideas
  if exist('za')
   [f,c,w]=cgml_coarsenstn1(a,s,za,pa);
  else
   error('CGML_AMGINIT4DD: Z does not exist with this smoother')
  end

 elseif strcmp(coarse,'p')
  % modifed Falgout algorithm
  [f,c,w]=cgml_coarsenp(a,s);

 elseif strcmp(coarse,'p1')
  % variant of the preceding one
  [f,c,w]=cgml_coarsenp1(a,s);

 elseif strcmp(coarse,'im')
  % coarsening using M
  if exist('m')
   [f,c,w]=cgml_coarsenstin(a,m,s);
  else
   error('CGML_AMGINIT4DD: M does not exist with this smoother')
  end

 elseif strcmp(coarse,'iz')
  % coarsening using Z
  if exist('zap')
   zzt=zap+zap'-spa;
   [f,c,w]=cgml_coarsenstin(a,zzt,s);
  else
   error('CGML_AMGINIT4DD: Z does not exist with this smoother')
  end

 elseif strcmp(coarse,'sd')
  % standard with dd interface (boundary first)
  s=cgml_influstb(a,alp);
  w=cgml_wght(s);
  ns=size(a,1);
  %s=sparse(ns,ns);
  overlap=find(cnsd == 0);
  if length(overlap) ~= 0
   % coarsen the interface (overlap)

   % add the neighbours of the interface nodes
   ovl=overlap;
   
   if addn == 1
    for i=overlap
     ni=cgml_neighb(s,i);
     ovl=[ovl ni];
    end % for i
    ovl=cgml_compr(ovl);
   end % if addn

   aovl=a(ovl,ovl);
   sovl=cgml_influstb(aovl,alp);
   s(ovl,ovl)=sovl;
   [fovl,covl,w(ovl)]=cgml_coarsenstloc2(aovl,sovl,w(ovl),l);

   flagc=1;
   if flagc == 1
    % flag the neighbours of the coarse nodes of the overlap as fine nodes
    % if this does not introduce fine-fine connections
    indc=find(w == -100);
    for i=indc
     ind=find(s(:,i) > 0 & w' > -50);
     %w(ind)=-50;
     for j=ind'
      %indk=find(s(:,j) >0 & w' > -50);
      indk=find(s(:,j) >0 & w' == -50);
      if length(indk) == 0
       % no fine node in the neighborhood, flag as fine
       w(j)=-50;
       indk=find(s(:,j) >0 & w' > -50);
       % increase their weight
       w(indk)=w(indk)+1;
      end % if length
     end % for j

     % decrease the weight of the nodes which are influenced by i
     ind=find(s(i,:) > 0 & w > -50);
     w(ind)=w(ind)-1;
    end % for i
   end % if flagc

  end % if length(overlap)

  % local coarsening of the subdomains
  sempty=0;

  for iSD=1:numsd
   ww=zeros(1,n);
   % local influence matrix without the overlapping
   nodeSDint=find( cnsd == iSD);
   aSD=a(nodeSDint,nodeSDint);
   sSD=cgml_influstb(aSD,alp);
   s(nodeSDint,nodeSDint)=sSD;
   if nnz(sSD) == 0
    if iprint >= 1
     disp('CGML_AMGINIT4DD: coarsening sd, Pb SSD is empty')
     [nnz(sSD) iSD]
    end
    % go up one level and stop
    if l == 1
     error('CGML_AMGINIT4DD: cannot go back to level 1')
    else % if l
     lmax=l-1;
    end % if l
    % need to compute the Cholesky decomposition of the last matrix
    caa=ca{l-2};
    r=chol(caa);
    cl(lmax)={r};
    if iprint >= 1
     disp(' ')
     str=sprintf('after correction final number of levels = %g',lmax);
     disp(str)
    end
    sempty=1;
    break % for
   end % if nnz
   
   % local coarsening 
   [fSD,cSD,ww(nodeSDint)]=cgml_coarsenstloc2(aSD,sSD,w(nodeSDint),l);
   w(nodeSDint)=ww(nodeSDint);
  end % for iSD
  
  if sempty == 1
   break % while done
  end
  f=find(w == -50);
  c=find(w == -100);
  
 elseif strcmp(coarse,'si')
  % standard with dd coarse interface
  s=cgml_influstb(a,alp);
  w=cgml_wght(s);
  ns=size(a,1);
  %s=sparse(ns,ns);
  overlap=find(cnsd == 0);
  
  if length(overlap) ~= 0
   % coarsen the interface
   % add the neighbours of the interface nodes
   ovl=overlap;
   
   addn=0; % for 'si' do not add the neighbours
   if addn == 1
    for i=overlap
     ni=cgml_neighb(s,i);
     ovl=[ovl ni];
    end % for i
    ovl=cgml_compr(ovl);
   end % if addn
   
   aovl=a(ovl,ovl);
   sovl=cgml_influstb(aovl,alp);
   s(ovl,ovl)=sovl;
   if nnz(sovl) == 0
    if iprint >= 1
     disp('CGML_AMGINIT4DD: coarsening si Pb: Sovl is empty')
    end
    % go up one level and stop
    if l == 1
     error('CGML_AMGINIT4DD: cannot go back to level 1')

    else % if l
     lmax=l-1;
    end % if l
    % need to compute the Cholesky decomposition of the last matrix
    caa=ca{l-2};
    r=chol(caa);
    cl(lmax)={r};
    if iprint >= 1
     disp(' ')
     str=sprintf('after correction final number of levels = %g',lmax);
     disp(str)
    end
    break % while done
   end % if nnz
   
   % all the interface nodes are coarse
   w(ovl)=-100;
   
   flagc=1;
   if flagc == 1
    % flag the neighbours of coarse nodes as fine nodes
    indc=find(w == -100);
    for i=indc
     ind=find(s(:,i) > 0 & w' > -50);
     %w(ind)=-50;
     for j=ind'
      %indk=find(s(:,j) >0 & w' > -50);
      indk=find(s(:,j) >0 & w' == -50);
      if length(indk) == 0
       % no fine node in the neighborhood, flag as fine
       w(j)=-50;
       indk=find(s(:,j) >0 & w' > -50);
       % increase their weight
       w(indk)=w(indk)+1;
      end % if length
     end
     
     % decrease the weights of nodes which are influenced by i
     ind=find(s(i,:) > 0 & w > -50);
     w(ind)=w(ind)-1;
    end
   end % if flagc
  end % if length(overlap)
  
  % local coarsening of the subdomains
  sempty=0;
  for iSD=1:numsd
   ww=zeros(1,n);
   % local influence matrix without the overlapping
   nodeSDint=find( cnsd == iSD);
   aSD=a(nodeSDint,nodeSDint);
   sSD=cgml_influstb(aSD,alp);
   s(nodeSDint,nodeSDint)=sSD;
   if nnz(sSD) == 0
    if iprint >= 1
     disp('CGML_AMGINIT4DD: coarsening si Pb: S is empty')
     [nnz(sSD) iSD]
    end
    % go up one level and stop
    if l == 1
     error('CGML_AMGINIT4DD: cannot go back to level 1')
    else % if l
     lmax=l-1;
    end % if l
    % need to compute the Cholesky decomposition of the last matrix
    caa=ca{l-2};
    r=chol(caa);
    cl(lmax)={r};
    if iprint >= 1
     disp(' ')
     str=sprintf('after correction final number of levels = %g',lmax);
     disp(str)
    end
    sempty=1;
    break % for
   end % if nnz
   
   % local coarsening 
   [fSD,cSD,ww(nodeSDint)]=cgml_coarsenstloc2(aSD,sSD,w(nodeSDint),l);
   w(nodeSDint)=ww(nodeSDint);
  end % for iSD
  
  if sempty == 1
   break % while done
  end
  f=find(w == -50);
  c=find(w == -100);
 
 elseif strcmp(coarse,'so')
  % standard with dd overlapping
  s=cgml_influstb(a,alp);
  w=cgml_wght(s);
  % coarsen the overlap
  if length(overlap) ~= 0
   aovl=a(overlap,overlap);
   sovl=cgml_influstb(aovl,alp);
   s(overlap,overlap)=sovl;
   if nnz(sovl) == 0
    if iprint >= 1
     disp('CGML_AMGINIT4DD: coarsening so, Pb Sovl is empty')
    end
    % go up one level and stop
    if l == 1
     error('CGML_AMGINIT4DD: cannot go back on level 1')
    else % if l
     lmax=l-1;
    end % if l
    % need to compute the Cholesky decomposition of the last matrix
    caa=ca{l-2};
    r=chol(caa);
    cl(lmax)={r};
    if iprint >= 1
     disp(' ')
     str=sprintf('after correction final number of levels = %g',lmax);
     disp(str)
    end
    break % while done
   end % if nnz
   
   [fovl,covl,w(overlap)]=cgml_coarsenstloc1(aovl,sovl,w(overlap));
   % flag the neighbours of coarse nodes as fine nodes
   indc=find(w == -100);
   for i=indc
    ind=find(s(:,i) > 0 & w' > -50);
    w(ind)=-50;
    for j=ind'
     indk=find(s(:,j) >0 & w' > -50);
     % increase their weight
     w(indk)=w(indk)+1;
    end % for j
    
    % decrease the weight of nodes which are influenced by i
    ind=find(s(i,:) > 0 & w > -50);
    w(ind)=w(ind)-1;
   end % for i
  end % if length
  
  % local coarsening
  sempty=0;
  for iSD=1:nbsd
   ww=zeros(1,n);
   % local influence matrix without the overlapping
   nodeSDint=find( nSD == iSD);
   if length(nodeSDint) ~= 0
    aSD=a(nodeSDint,nodeSDint);
    sSD=cgml_influstb(aSD,alp);
    s(nodeSDint,nodeSDint)=sSD;
    if nnz(sSD) == 0
     if iprint >= 1
      disp('CGML_AMGINIT4DD: coarsening so, Pb S local is empty')
      [nnz(sSD) iSD]
     end
     % go up one level and stop
     if l == 1
      error('CGML_AMGINIT4DD: cannot go back to level 1')
     else % if l
      lmax=l-1;
     end % if l
     % need to compute the Cholesky decomposition of the last matrix
     caa=ca{l-2};
     r=chol(caa);
     cl(lmax)={r};
     if iprint >= 1
      disp(' ')
      str=sprintf('after correction final number of levels = %g',lmax);
     disp(str)
     end
     sempty=1;
     break % for
    end % if nnz
    
    % local coarsening 
    [fSD,cSD,ww(nodeSDint)]=cgml_coarsenstloc1(aSD,sSD,w(nodeSDint));
    w(nodeSDint)=ww(nodeSDint);
   end % if length
  end % for iSD
  
  if sempty == 1
   break % while done
  end
  f=find(w == -50);
  c=find(w == -100);
  c=sort(c);
  nSD=nSD(c);
  [perm1,iSDnodes,overlap]=cgml_findcoarse(perm1,iSDnodes,overlap,c);
  
 else
  % my 'm2' algorithm
  if exist('m')
   [f,c,w]=cgml_coarsenm2(a,s,m,alp);
  else
   error('CGML_AMGINIT4DD: M doest not exist with this smoother')
  end
 end
 
 % get the subdomain number of the coarse nodes for next level
 cnsd=cnsd(sort(c));
 % permutation
 p=[sort(f) sort(c)];
 cperm(l)={p};
 ap=a(p,p);
 ip=cgml_invperm(p);
 ciperm(l)={ip};
 dimf=length(f);
 dimc=length(c);

 % interpolation
 itp=0;
 
 if strcmp(interpo,'st')
  % standard AMG interpolation
  weight=cgml_winterp(a,s,f,c,w);
  
 elseif strcmp(interpo,'sc')
  % Schur interpolation with M
  if exist('m')
   mp=m(p,p);
   weight=-mp(1:dimf,1:dimf)*ap(1:dimf,dimf+1:n);
  else
   error('CGML_AMGINIT4DD: M doest not exist with this smoother')
  end
  
 elseif strcmp(interpo,'im')
  % interpolation using the approximate inverse M
  if exist('m')
   weight=cgml_wintinv(m,f,c,w);
  else
   error('CGML_AMGINIT4DD: M doest not exist with this smoother')
  end
  
 elseif strcmp(interpo,'iz')
  % interpolation using Z
  if exist('zap')
   zzt=zap+zap'-spa;
   weight=cgml_wintinv(zzt,f,c,w);
  else
   error('CGML_AMGINIT4DD: Z doest not exist with this smoother')
  end
  
 elseif strcmp(interpo,'em')
  % energy minimization interpolation (Wan and Chan like)
  itp=1;
  prol=cgml_enermin(a,f,c);
  prol=prol(p,:);
  
 elseif strcmp(interpo,'ez')
  % energy minimization using Z (?)
  if exist('zap')
   itp=1;
   zzt=zap+zap'-spa;
   prol=cgml_enermin(zzt,f,c);
   prol=prol(p,:);
  else
   error('CGML_AMGINIT4DD: Z doest not exist with this smoother')
  end
  
 elseif strcmp(interpo,'wi')
  % Wagner like interpolation with minimization
  if exist('sm')
   weight=cgml_wagint(a,s,sm,f,c,w);
  else
   error('CGML_AMGINIT4DD: SM doest not exist with this smoother')
  end
  
 elseif strcmp(interpo,'wm')
  % my algorithm (with neighbours of neighbours)
  weight=cgml_wmeur(a,f,c,w);
  
 else
  error('CGML_AMGINIT4DD: this interpolation algorithm does not exist')
 end
 
 cf(l)={f};
 cc(l)={c};
 cw(l)={w};
 cdf(l)={length(f)};
 
 % interpolation (prolongation) matrix prol
 if itp == 0
  prol=[weight ; speye(dimc,dimc)];
 end
 cp(l)={prol};
 
 % restriction matrix (needs to be symmetric for CG)
 res=prol';
 cr(l)={res};
 
 % coarse matrix
 % always use Galerkin
 a=res*ap*prol;
 
 if normal ==1
  [a,da]=cgml_normaliz(a);
 end
 
 ca(l)={a};
 if normal == 1
  cda(l+1)={da};
 end
 
 nn=length(c);
 if (nnold-nn)/nnold <= 0.05
  % not enough difference of number of nodes between two consecutive levels
  % solve exactly
  lmax=l;
 else
  nnold=nn;
 end
end

if lmax > 0
 % viz of the coarse grids (only for grid problems)
 % for other problems comment the next line
 %plotgridsp(cs,cw,cnosd,lmax,perm,nbsd)
 
 stockz=0;
 stockm=0;
 for l=1:lmax-1
  p=cp{l};
  d=cdb{l};
  a=ca{l};
  w=cw{l};
  m=cm{l};
  z=czb{l};
  nos=cnosd{l};
  nnzn=nnz(z);
  nnzd=nnz(d);
  if smooth == 'gs'
   nnzn=0;
   nnzd=0;
  end
 
  % statistics
  % total storage for z and m
  stockz=stockz+nnz(z);
  stockm=stockm+nnz(m);
  totstr=totstr+nnz(a)+nnzn+nnzd+nnz(p);
  totpt=totpt+size(a,1);
  tota=tota+nnz(a);
  %
  %for nd=1:nbsd
  % ind=find(nos==nd);
  % nbnd(nd)=length(ind);
  %end
  %ind=find(nos==0);
  %nb0=length(ind);
  
  if iprint >= 1
   str=sprintf('level %g',l);
   str0=sprintf(', n=%g',size(cz{l},1));
   str1=sprintf(' storage a %g',nnna(l));
   str2=sprintf(' storage z %g',nnnz(l));
   disp(' ')
   disp([str str0])
   disp(str1)
   disp(str2)
  end
 end
 if iprint >= 1
  disp(' ')
  sgrid=totpt/nmax;
  sa=tota/nnza;
  str=sprintf('total storage = %g',totstr);
  str0=sprintf(', /n= %g',totstr/nmax);
  str01=sprintf(', /nnza= %g',totstr/nnza);
  str1=sprintf(', sgrid= %g',sgrid);
  str2=sprintf(', sa= %g',sa);
  disp([str str0 str01 str1 str2])
  pause
 end
 
end

