function [ci,indi]=cgml_coarsno1(s,w,i);
%CGML_COARSENO1 find the coarse nodes and neigbours of i in s
% w = -100 for coarse nodes
% assume the diagonal is zero
%
% Author G. Meurant
% Aug 2000
%

indi=find(s(i,:));
% this is useless is is an influence matrix
%indi=cgml_setdiff(indi,i);
if length(indi) ~= 0
 wi=w(indi);
 % coarse nodes
 indci=find(wi == -100);
 if length(indci) ~= 0
  ci=indi(indci);
 else
  ci=[];
 end
else
 indi=[];
 ci=[];
end


