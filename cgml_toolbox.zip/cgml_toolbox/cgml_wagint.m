function weight=cgml_wagint(a,s,sm,f,c,w);
%CGML_WAGINT computes the interpolation weights inspired by Wagner's interpolation
%
% a matrix
% s influence matrix
% sm=I-MA
% cannot be used with smoothers not defined by Richardson
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% WARNING : may compute negative weights !!!!
%
% Author G. Meurant
% Aug 2000
%

n=size(a,1);
weight=sparse(n,n);

for i=f
 % find the coarse neighbours in s c_i, neighbours indi
 [ci,indi]=cgml_coarsno(s,w,i);
 lci=length(ci);
 if lci == 0
  error('CGML_WAGINT: no coarse neighbour in S')
 end
 
 % compute the linear system for the minimization
 nq=lci+1;
 q=sparse(nq,nq);
 kl=0;
 si=sm(i,:);
 for k=ci
  kl=kl+1;
  sk=sm(k,:);
  secm(kl)=-si*sk';
  kj=0;
  for l=ci
   kj=kj+1;
   sl=sm(l,:);
   q(kl,kj)=sk*sl';
  end
  q(kl,nq)=1;
 end
 % last line for the lagrange multiplier
 q(nq,1:lci)=ones(1,lci);
 secm(nq)=1;
 % solve
 pik=q\secm(1:nq)';
 weight(i,ci)=pik(1:lci)';
end

weight=sparse(weight);
p=[sort(f) sort(c)];
dimf=length(f);
wp=weight(p,p);
weight=wp(1:dimf,dimf+1:n);


