function ip=cgml_invperm(perm);
%CGML_INVPERM inverse permutation of perm
%
% Author G. Meurant
% 2000
%

n=length(perm);
in=[1:n];
ip=perm;
ip(perm)=in;