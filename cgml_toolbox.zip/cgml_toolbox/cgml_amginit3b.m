function [ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,czb,cdb,cl,cda,lmax,err]=cgml_amginit3b(a,alpmax,alb,lmax,falp,qmin,alq,smooth,infl,coarse,interpo,normal,tb,iprint);
%CGML_AMGINIT3B init of block multi level iteration
%
% f and c are the fine and coarse nodes
% l=1 fine grid, l=lmax coarsest grid
%
% Input
%  matrix = a, rhs = b, init vector = x0,
%  stop crit = epss
%  truncation coeff = almax for the grid and alb for smoothing
%  max nb levels = lmax
%  smoother = smooth, influence type = influ, coarsening type = coarse
%  interpolation: interpo
%  gama=1 V-cycle, gama=2 W-cycle
%  smooth = smoother
%  infl = mode of computation of the influence matrix
%  coarse = coarsening algorithm
%  interpo = interpolation algorithm
%  normalization = normal
%  print level = iprint
%
% Output
%  matrices for each level in cell arrays
% ca = matrix on level l
% cm = preconditioner on level l
% cp = prolongation on level l
% cr = restriction on level l
% cperm = permutation on level l
% ciperm = inverse permutation on level l
% cdf = number of fine nodes on level l
% cz = factor of the AINV decomposition on level l (coarsening)
% cd = diagonal factor of the AINV dec on level l (coarsening)
% czb = factor of the AINV decomposition on level l (smoothing)
% cdb = diagonal factor of the AINV dec on level l (smoothing)
% cl = Cholesky factor (for the coarsest level only)
%
% author G. Meurant
% Aug 2006
%

if normal == 1
 [ad,da]=cgml_normaliz(a);
 cda(1)={da};
else
 cda(1)={[]};
end

err=0;
done=0;
alp=alpmax;
alpb=alb;
q=qmin;
nmax=size(a,1);
nnza=nnz(a);
totstr=nnza;
tota=totstr;
totpt=nmax;
% exact solve if less than nmin nodes
nmin=9;


% start going down the levels
l=0;
nnold=size(a,1);
while done == 0
 n=size(a,1);
 
 if n <= nmin | l == lmax
  % coarsest level
  if iprint >= 1
   disp(' ')
   disp('CGML_AMGINIT3B: stop the recursion')
   disp('--------------------')
   disp(' ')
  end
  lmax=l;
  
  if l > 1
   caa=ca{l-1};
   % compute Cholesky decomposition for the exact solve
   r=chol(caa);
   cl(l)={r};
  else
   err=1;
   return
  end
  if iprint >= 1
   disp(' ')
   str=sprintf('number of levels = %g',lmax);
   disp(str)
  end
  break
 end
 
 if iprint >= 1
  str=sprintf(' Smoother = %s',smooth);
  disp(str)
 end
 
 % go down the levels
 l=l+1;
 
 % modification to truncate on all levels except the fine one
 %if l == 1
 % q=nmax;
 %else
 % q=qmin;
 %end
 
 % initialize the cell arrays
 cf(l)={[]};
 cc(l)={[]};
 cw(l)={[]};
 cdf(l)={[]};
 cz(l)={[]};
 cd(l)={[]};
 cp(l)={[]};
 ca(l)={[]};
 cm(l)={[]};
 cl(l)={[]};
 czb(l)={[]};
 cdb(l)={[]};
 cda(l+1)={[]};
 zb=[];
 pb=[];
 nz_of_A=nnz(a);
 if iprint >= 1
  str=sprintf('level = %g',l);
  str1=sprintf(', n = %g',n);
  disp(' ')
  disp(['----------------- ' str str1])
  sprintf(' nb of non zero entries = ', nz_of_A);
  disp(str)
 end
 
 if strcmp(smooth,'gs') 
  % Symmetric Gauss-Seidel smoother
  tl=tril(a);
  tu=tl';
  % store the smoother
  cz(l)={tl};
  cd(l)={tu};
  czb(l)={tl};
  cdb(l)={tu};
  nnna(l)=nnz(a);
  nnnz(l)=0;
  za=tl;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'gb') | strcmp(smooth,'gn')
  % Symmetric block Gauss-Seidel smoother
  % block lower triangular part
  tl=cgml_trilb(a,tb);
  tu=tl';
  % store the smoother
  cz(l)={tl};
  cd(l)={tu};
  czb(l)={tl};
  cdb(l)={tu};
  nnna(l)=nnz(a);
  nnnz(l)=0;
  za=tl;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'ic')
  % Incomplete Cholesky smoother
  % IC(0) of a general matrix
  [dd,ll]=cgml_chicopt(a);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT3B: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;
   
 elseif strcmp(smooth,'ib')
  % block Incomplete Cholesky smoother
  % block IC(0) of a general matrix
  [dd,ll,dd1]=cgml_icbopt(a,tb);
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;
  
 else
  error('CGML_AMGINIT3B: smoother not implemented')
 end
 
 % block influence matrix
 s=cgml_influstbl(a,alp,tb);
 cs(l)={s};
 % modify the values of parameters for next level
 alp=falp*alp;
 alpb=falp*alpb;
 q=fix(alq*q);
 
 % if there is nothing in S 
 % go up one level and stop the coarsening process
 if nnz(s) == 0 
  if iprint >=1
   disp('Pb: S is empty')
   [nnz(s)]
  end
  % go up one level and stop
  if l == 1
   error('CGML_AMGINIT3B: cannot go back to level 1')
  else
   lmax=l-1;
  end
  % need to compute the Cholesky decomposition of the last matrix
  caa=ca{l-2};
  r=chol(caa);
  cl(lmax)={r};
  if iprint >= 1
  disp(' ')
   str=sprintf('after correction final number of levels = %g',lmax);
   disp(str)
  end
  break
 end
 
 % construction of block coarse mesh
 
 if strcmp(coarse,'st')
  % standard algorithm
  % Note: a is not used in coarsenstnew
  [f,c,w]=cgml_coarsenstnew(a,s);
  
 elseif strcmp(coarse,'cl')
  % (modified) CLJP algorithm
  [f,c,w]=cgml_coarsencljp(a,s);
  
 elseif strcmp(coarse,'pm')
  % PMIS algorithm
  [f,c,w]=cgml_coarsenpmis(a,s);
  
 elseif strcmp(coarse,'hm')
  % HMIS algorithm
  [f,c,w]=cgml_coarsenhmis(a,s);
  
 elseif strcmp(coarse,'fa')
  % (modified) CLJP algorithm
  [f,c,w]=cgml_coarsenfalg(a,s);
  
 else
  error('CGML_AMGINIT3B: this block coarsening algorithm does not exist')
 end
 
 % f and c give the indices of the blocks
 % from this, construct the indices of the points within the blocks
 [f,c,w]=cgml_ptindex(a,f,c,w,tb);
 % promote block s to point form
 s=cgml_pts(s,tb);
 
 % permutation
 p=[sort(f) sort(c)];
 cperm(l)={p};
 ap=a(p,p);
 ip=cgml_invperm(p);
 ciperm(l)={ip};
 dimf=length(f);
 dimc=length(c);
 
 % interpolation
 itp=0;
 if strcmp(interpo,'st')
   na=size(a,1);
   aa=sparse(n,n);
   aa(find(s(:)))=a(find(s(:)));
   aa=aa+diag(diag(a));
  % standard AMG interpolation
  weight=cgml_winterp(aa,s,f,c,w);
 else
  error('CGML_AMGINIT3B: the only available interpolation algo is st');
 end
 
 cf(l)={f};
 cc(l)={c};
 cw(l)={w};
 cdf(l)={length(f)};
 
 % interpolation (prolongation) matrix prol
 if itp == 0 
  prol=[weight ; speye(dimc,dimc)];
 end
 cp(l)={prol};
 
 % restriction matrix (needs to be symmetric for CG)
 res=prol';
 cr(l)={res};
 
 % coarse matrix always use Galerkin
 a=res*ap*prol;
 if normal ==1
  [a,da]=normaliz(a);
 end
 ca(l)={a};
 if normal == 1
  cda(l+1)={da};
 end
 nn=length(c);
 
 %if (nnold-nn)/nnold <= 0.2
 %if (nnold-nn)/nnold <= 0.1
 if (nnold-nn)/nnold <= 0.05
  if iprint >= 1
   disp(' not enough difference')
  end
  % not enough difference of number of nodes between two consecutive levels
  % solve exactly
  lmax=l;
  nnold=nn;
 else
  nnold=nn;
 end
 
end

if lmax > 0
 
 % viz of the coarse grids (only for grid problems)
 % for other problems comment the next line
 %plotgrids1(cs,cw,lmax)
 
 stockz=0;
 stockm=0;
 for l=1:lmax
  p=cp{l};
  d=cdb{l};
  a=ca{l};
  w=cw{l};
  m=cm{l};
  z=czb{l};
  nnzn=nnz(z);
  nnzd=nnz(d);
  if strcmp(smooth,'gs') | strcmp(smooth,'po')
   nnzn=0;
   nnzd=0;
  end
  if strcmp(smooth,'tw')
   nnzd=0
  end
 
  if iprint >= 1
   % statistics
   % total storage for z and m
   stockz=stockz+nnz(z);
   stockm=stockm+nnz(m);
   totstr=totstr+nnz(a)+nnzn+nnzd+nnz(p);
   totpt=totpt+size(a,1);
   tota=tota+nnz(a);
   str=sprintf('level %g',l);
   str0=sprintf(', n = %g',size(cz{l},1));
   str1=sprintf(' storage a %g',nnna(l));
   str2=sprintf(' storage z %g',nnnz(l));
   disp(' ')
   disp([str str0])
   disp(str1)
   disp(str2)
  end
  
 end
 
 if iprint >= 1
  disp(' ')
  sgrid=totpt/nmax;
  sa=tota/nnza;
  str=sprintf('total storage = %g',totstr);
  str0=sprintf(', /n = %g',totstr/nmax);
  str01=sprintf(', /nnza = %g',totstr/nnza);
  str1=sprintf(', sgrid = %g',sgrid);
  str2=sprintf(', sa = %g',sa);
  disp([str str0 str01 str1 str2])
 end
 
end