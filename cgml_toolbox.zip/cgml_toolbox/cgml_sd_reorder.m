function [ddo] = cgml_sd_reorder(A,partsd,vsep,numsd,nbnodes,method);
%CGML_SD_REORDER find new ordering from a given numbering obtained by graph partitioning
%
% find a new ordering of the matrix A such that:
% the matrices associated to subdomains are reorder in order to reduce the fill-in
%
% partsd : nodes in sd
% vsep : vertex separators
%
% returns "ddo" (domain decomposition ordering) of A with fill-in reduction within subdomains
%

if method == 'md'
 % mimumum degree
 ideb = 1;
 pnew = [];
 
 for isd = 1:numsd  % one subdomain reordering at a time
  sdnum = partsd(ideb:ideb+nbnodes(isd)-1);
  %psd = symmmd( A(sdnum,sdnum) );
  psd = symamd( A(sdnum,sdnum) );
  ideb = ideb + nbnodes(isd);
  pnew = [pnew,sdnum(psd)];
 end
 
elseif method == 'rc'
 % reverse Cuthill-McKee
 psd = symrcm(A(partsd,partsd));
 pnew = partsd(psd);
 
else
 % do nothing
 pnew=partsd;
end

ddo = [pnew, vsep];


