function [s]=cgml_influmt(a);
%CGML_INFLUMT influence matrix of a, |a(i,j)| > 0, q largest elements
%
% computes a sparse matrix s of ones where |a(i,j)| > 0
% keep only the q largest elements
%
% author G. Meurant
% Aug 2000
%
 
q=2;
n=size(a,1);
t=abs(triu(a,1));
s=sparse(n,n);
for i=1:n-1
 ind= find(t(i,:) > 0);
 lti=length(ind);
 if lti > 0
  qq=min(q,lti);
  % find the q largest in t
  [x,indx]=sort(t(i,i+1:n));
  lx=length(indx);
  indl=indx(lx-qq+1:lx)+i;
  s(i,indl)=spones(indl);
 end
end
s=s+s';
if nnz(s) == 0
 error('CGML_INFLUMT: influmt, S is empty!')
end
