function [AllNodes,overlap] = cgml_neighbours_by_front(layers,InsideNodes,A)
%CGML_NEIGHBOURS_BY_FRONT Enlarge the Inside Nodes of a given Subdomain with layers sets of neighbours
%
% From P. Leca
% December 2001
%

overlap = [];
if layers <= 0;
 AllNodes = InsideNodes;
else

 % Initialization of front
 front = InsideNodes;
 part1 = [front];
 n = size(A,1);
 X = zeros(n,1);
 % vector X correspond to a partition
 X(part1) = 1;
 S = spones(A);
 % Build new front from sparse matrix * vector
 Xnew = S*X;
 Xnew = spones(Xnew) -  X;
 front = find(Xnew);

 overlap = [overlap,front'];
 part1 = [part1, front'];
 X(part1) = 1;
 layers = layers - 1;
 
 while layers > 0
  Xnew = S*X;
  Xnew = spones(Xnew) - X;
  front = find(Xnew);
  overlap = [overlap,front'];
  part1 = [part1, front'];
  X(part1) = 1;
  layers = layers - 1;
 end
 
 AllNodes = part1;
end