function s=cgml_influst(a,alp);
%CGML_INFLUST influence matrix of a, standard AMG
%  
% computes a sparse matrix s of ones where
% |a(i,j)| >= alp * max_i |a(i,k)|
%
% author G. Meurant
% Aug 2000
%
 
maxs=max(abs(a'))';
n=size(a,1);
s=sparse(n,n);
for i=1:n
 ind= find(abs(a(i,:)) >= alp*maxs(i));
 s(i,ind)=spones(ind);
end
s=s-diag(diag(s));
if nnz(s) == 0
 error('CGML_INFLUST: S is empty!')
end
