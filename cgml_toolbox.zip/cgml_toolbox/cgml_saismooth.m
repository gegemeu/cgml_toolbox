function x=cgml_saismooth(a,m,b,x0,nu);
%CGML_SAISMOOTH SAI Richardson smoothing for AMG
%
% nu iterations
% the preconditioner is M 
% computed by an SAI routine
%
% Author G. Meurant
% Sept 2000
%

x=x0;

for i=1:nu
 x=x+m*(b-a*x);
end

