function [d,l,d1]=cgml_icbopt(a,tb);
%CGML_ICBOPT  Block incomplete Cholesky decomposition IC(0) of a sparse matrix
% l * d * l' with d matrix and l unit lower triangular
% tb block size
% d is a block diagonal matrix
%
% Author G. Meurant
% july 2006
%

n=size(a,1);
b=a;
l=sparse(n,n);
d=sparse(n,n);
d1=sparse(n,n);

% number of blocks
nb=n/tb;
if rem(n,tb) ~= 0
 error('CGML_ICBOPT: wrong block size')
end

for kk=1:nb-1
 k=(kk-1)*tb+1;
 ktb=k+tb-1;
 m=size(b,1);
 bb=b(1:tb,1:tb);
 b1=inv(bb);
 al=a(ktb+1:n,k:ktb);
 indl=find(al);
 sl=sparse(m-tb,tb);
 bbl=b(tb+1:m,1:tb);
 sl(indl)=bbl(indl);
 sl=sl*b1;
 su=sl';
 l(ktb+1:n,k:ktb)=sl;
 l(k:ktb,k:ktb)=speye(tb);
 d(k:ktb,k:ktb)=bb;
 d1(k:ktb,k:ktb)=b1;
 % Schur complement
 bc=b(tb+1:m,tb+1:m);
 bc=bc-sl*bb*su;
 b=bc;
end

l(n-tb+1:n,n-tb+1:n)=speye(tb);
d(n-tb+1:n,n-tb+1:n)=b;
d1(n-tb+1:n,n-tb+1:n)=inv(b);


