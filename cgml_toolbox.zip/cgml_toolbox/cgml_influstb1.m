function s=cgml_influstb1(a,alp);
%CGML_INFLUSTB1 influence matrix of a standard AMG choice
%
% computes a sparse matrix s of ones where
% |a(i,j)| >= alp * max_i |a(i,k)|
% keep at least one element per row
% optimzed version of cgml_influstb???
%
% author G. Meurant
% Mar 2009
% corrected Sept 2010
%
 
maxs=max(abs(a'))';
a=a-diag(diag(a));

if nnz(a) == 0
 disp('CGML_INFLUSTB: A is diagonal')
 s=spones(a);
 return
end

n=size(a,1);

c=abs(a)-alp*maxs*ones(1,n);

s=spones(c>=0);

% correction to avoid zero rows

for i = 1:size(a,1)
 ss = s(i,:);
 if nnz(ss) == 0
  [y,j]=max(abs(a(i,:)));
  s(i,j(1)) = 1;
 end
end

