function [ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,czb,cdb,cl,cda,lmax,err]=cgml_amginit3(a,alpmax,alb,lmax,falp,qmin,alq,smooth,infl,coarse,interpo,normal,iprint);
%CGML_AMGINIT3 init of multi level preconditioner
%
% f and c are the fine and coarse nodes
% l=1 fine grid, l=lmax coarsest grid
%
% Input
%  matrix = a, rhs = b, init vector = x0,
%  stop crit = epss
%  truncation coeff = almax for the grid and alb for smoothing
%  max nb levels = lmax
%  smoother = smooth, influence type = influ, coarsening type = coarse
%  interpolation: interpo
%  gama=1 V-cycle, gama=2 W-cycle
%  smooth = smoother
%  infl = mode of computation of the influence matrix
%  coarse = coarsening algorithm
%  interpo = interpolation algorithm
%  normalization = normal
%  print level = iprint
%
% Output
%  matrices for each level in cell arrays
%  ca = matrix on level l (ell)
%  cm = preconditioner on level l
%  cp = prolongation on level l
%  cr = restriction on level l
%  cperm = permutation on level l
%  ciperm = inverse permutation on level l
%  cdf = number of fine nodes on level l
%  cz = factor of the AINV decomposition on level l (coarsening)
%  cd = diagonal factor of the AINV dec on level l (coarsening)
%  czb = factor of the AINV decomposition on level l (smoothing)
%  cdb = diagonal factor of the AINV dec on level l (smoothing)
%  cl = Cholesky factor (for the coarsest level only)
%
% author G. Meurant,
% Aug 2000
%

if normal == 1
 [ad,da]=cgml_normaliz(a);
 cda(1)={da};
else
 cda(1)={[]};
end

err=0;
done=0;
alp=alpmax;
alpb=alb;
q=qmin;
nmax=size(a,1);
nnza=nnz(a);

% estimate of the condition number of A with Lanczos (50 it) ?????????????
%[lmin,lmaxx,se]=lancz(a,50);
%kap=lmaxx/lmin

totstr=nnza;
tota=totstr;
totpt=nmax;
% exact solve if less than nmin nodes
nmin=9;

% start going down the levels
l=0;
nnold=size(a,1);
while done == 0
 n=size(a,1);

 if n <= nmin | l == lmax
  % coarsest level
  if iprint >= 1
   disp(' ')
   disp('CGML_AMGINIT3: stop the recursion on levels')
   disp('--------------------')
   disp(' ')
  end
  lmax=l;
  if l > 1
   caa=ca{l-1};
   % compute Cholesky decomposition of the corasest matrix for the exact solve
   r=chol(caa);
   cl(l)={r};
  else
   % error if we just have one level
   err=1;
   return
  end
  if iprint >= 1
   disp(' ')
   str=sprintf('number of levels = %g',lmax);
   disp(str)
  end
  break
 end
 
 if iprint >= 1
  str=sprintf(' Smoother = %s',smooth);
  disp(str)
 end
 
 % go down the levels
 l=l+1;
 
 % modification to truncate on all levels except the fine one
 %if l == 1
 % q=nmax;
 %else
 % q=qmin;
 %end
 
 % initialize the cell arrays on level l (ell)
 cf(l)={[]};
 cc(l)={[]};
 cw(l)={[]};
 cdf(l)={[]};
 cz(l)={[]};
 cd(l)={[]};
 cp(l)={[]};
 ca(l)={[]};
 cm(l)={[]};
 cl(l)={[]};
 czb(l)={[]};
 cdb(l)={[]};
 cda(l+1)={[]};
 zb=[];
 pb=[];
 nz_of_A=nnz(a);
 if iprint >= 1
  str=sprintf('level=%g',l);
  str1=sprintf(', n=%g',n);
  disp(' ')
  disp(['----------------- ' str str1])
  str=sprintf(' nb of non zero entries = %g',nz_of_A);
  disp(str)
 end
 
 % Construct the smoother
 
 if strcmp(smooth,'gs') | strcmp(smooth,'ga')
  % Symmetric Gauss-Seidel smoother
  % gs = symmetric, ga = non symmetric
  tl=tril(a);
  tu=triu(a);
  % store the smoother
  cz(l)={tl};
  cd(l)={tu};
  czb(l)={tl};
  cdb(l)={tu};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   im=tl*diag(1./diag(a))*tl';
   m=inv(im);
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=0;
  za=tl;
  zap=a;
  spa=a;
 
 elseif strcmp(smooth,'ai') | strcmp(smooth,'cg')
  % AINV smoother or preconditoner for CG smoother
  % AINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet=0; % shift
  beta=bet*max(max(abs(a)));
  as=a+beta*speye(n);
  if abs(alp-alpb) > 1e-10
   [za,pa,zb,pb]=cgml_ainvn4(as,alp,alpb,q);
  else
   % if alp=alpb compute only one factorization
   [za,pa]=cgml_ainvn2(as,alp,q);
   zb=za;
   pb=pa;
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(za);
  if nnz(find(pa<0)) ~= 0
   disp(['CGML_AMGINIT3: non positive definite matrix on level' l])
  end
  % store the AINV factorizations
  cz(l)={za};
  cd(l)={pa};
  czb(l)={zb};
  cdb(l)={pb};
  % compute the preconditioner M = Z P Z'
  m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  cm(l)={m};
  
 elseif strcmp(smooth,'sa')
  % SAINV smoother
  % SAINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet=0; % shift
  beta=bet*max(max(abs(a)));
  as=a+beta*speye(n);
  if abs(alp-alpb) > 1e-10
   [za,pa,zb,pb]=cgml_sainvn4(as,alp,alpb,q);
  else
   % if alp=alpb compute only one factorization
   [za,pa]=cgml_sainvn2(as,alp,q);
   zb=za;
   pb=pa;
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(za);
  if nnz(find(pa<0)) ~= 0
   disp(['CGML_AMGINIT3: non positive definite matrix on level' l])
  end
  % store the AINV factorizations
  cz(l)={za};
  cd(l)={pa};
  czb(l)={zb};
  cdb(l)={pb};
  % compute the preconditioner M = Z P Z'
  m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  cm(l)={m};
  
 elseif strcmp(smooth,'tw')
  % Tang approximate inverse (symmetrized)
  m=cgml_saitw(a,0,1);
  cm(l)={m};
  cz(l)={m};
  cd(l)={m};
  czb(l)={m};
  cdb(l)={m};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(m);
  za=m;
  zap=m;
  spa=m;
 
 elseif strcmp(smooth,'po')
  % polynomial smoothing
  [lmi,lma]=cgml_gerschgo(a);
  lmi=max(0,lmi);
  % degree of the polynomial
  degpol=1;
  m=cgml_setmcarre(degpol,lmi,lma);
  cm(l)={m};
  czb(l)={lmi};
  cdb(l)={lma};
  cz(l)={a};
  cd(l)={a};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(a);
  za=a;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'ma')
  % multiplication by 2D-A
  di=diag(diag(a));
  m=2*di-a;
  cm(l)={m};
  czb(l)={m};
  cdb(l)={m};
  cz(l)={a};
  cd(l)={a};
  nnna(l)=nnz(a);
  nnnz(l)=nnz(a);
  za=a;
  zap=a;
  spa=a;
 
 elseif strcmp(smooth,'ic')
  % Incomplete Cholesky smoother IC(0) of a general matrix
  [dd,ll]=cgml_chicopt(a);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT3: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'ch')
  % Incomplete Cholesky with fill IC(epsilon) of a general matrix
  [dd,ll]=cgml_chepsopt(a,alb);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CGML_AMGINIT3: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'lv')
  % Incomplete Cholesky with levels IC(level) of a general matrix
  ialb=fix(alb);
  if ialb == 0
   ialb=1;
  end
  [dd,ll]=cgml_chlevopt(a,ialb);
  ind=find(dd<0);
  if length(ind) ~= 0
   disp('CGML_AMGINIT3: Pb with incomplete factorization')
  end
  dd=1./dd;
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'sh')
  % Incomplete Cholesky of Manteuffel with shift and levels
  % IC(level) of a general matrix
  % 3 retries
  if iprint == 0
   [lu,bdown]=cgml_miluk(a,alb,3);
  else
   [lu,bdown]=cgml_miluk(a,alb,3,iprint);
  end
  ll=tril(lu);
  dd=diag(ll);
  ind=find(dd<0);
  if length(ind) ~= 0
   disp('CGML_AMGINIT3: Pb with incomplete factorization')
  end
  cz(l)={ll};
  cd(l)={dd};
  czb(l)={ll};
  cdb(l)={dd};
  % compute the Richardson matrix for 'wi' interpolation
  if strcmp(interpo,'wi') | strcmp(interpo,'wm')
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
   cm(l)={m};
  end
  nnna(l)=nnz(a);
  nnnz(l)=nnz(ll);
  za=ll;
  zap=a;
  spa=a;
  
 elseif strcmp(smooth,'gc')
  % CG with diagonal preconditioner smoother
  dd=1./diag(a);
  cd(l)={dd};
  cz(l)={a};
  za=a;
  cz(l)={za};
  czb(l)={za};
  cdb(l)={dd};
  nnna(l)=nnz(a);
  nnnz(l)=0;
  m=a;
  cm(l)={a};
  zap=a;
  spa=a;

 elseif strcmp(smooth,'bj')
  % tridiagonal smoother
  % corresponds to Block Jacobi for a rectangular mesh
  dd=diag(diag(a,0),0)+diag(diag(a,-1),-1)+diag(diag(a,1),1);
  cd(l)={dd};
  cz(l)={a};
  za=a;
  cz(l)={za};
  czb(l)={dd};
  cdb(l)={dd};
  nnna(l)=nnz(a);
  nnnz(l)=0;
  m=a;
  cm(l)={a};
  zap=a;
  spa=a;
 else
  error('CGML_AMGINIT3: smoother not implemented')
 end
 
 % smoothing operator (for 'wi' interpolation)
 if strcmp(interpo,'wi')
  sm=speye(n,n)-sparse(m*a);
 else
  sm=speye(n,n);
 end
  
 % influence matrix
 
 if strcmp(infl,'b')
  % same as the standard 'a' except keeps at least one element per row
  %s=cgml_influstb(a,alp);
  s=cgml_influstb1(a,alp);
  
 elseif strcmp(infl,'a')
  % corresponds to 'a': standard algorithm using A
  % and the strong connections defined by alpha
  s=cgml_influst(a,alp);
 
 elseif strcmp(infl,'m')
  % use the preconditioner M to define the coarse grid
  if exist('m')
   s=cgml_influm(m);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end

 elseif strcmp(infl,'mi')
  % variants of M (when there is not enough coarse nodes)
  % better to use 2 values of alpha
  if exist('m')
   s=cgml_influin(a,m,alp);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 elseif strcmp(infl,'mc')
  if exist('m')
   s=cgml_influ(m,alp);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 elseif strcmp(infl,'mt') | strcmp(infl,'mu')
  if exist('m')
   s=cgml_influmt(m);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 elseif strcmp(infl,'z')
  % when using AINV, use Z to define the coarse grid
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influm(zzt);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
   
 elseif strcmp(infl,'zc')
  % variants of Z
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influ(zzt,alp);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
  
 elseif strcmp(infl,'zi')
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influin(a,zzt,alp);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
  
 elseif strcmp(infl,'zt') | strcmp(infl,'zu')
  if exist('zap')
   zzt=zap+zap'-spa;
   s=cgml_influmt(zzt);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
  
 else
  error('CGML_AMGINIT3: this influence algorithm does not exist')
 end
 % store the influence matrix
 cs(l)={s};
 
 % modify the values of parameters for next level
 alp=falp*alp;
 alpb=falp*alpb;
 q=fix(alq*q);
 
 % if there is nothing in S or Z is diagonal
 % go up one level and stop the coarsening process
 if nnz(s) == 0 | nnz(za) == size(za,1)
  if iprint >= 1
   disp('Pb: S is empty or Z is diagonal')
   [nnz(s) nnz(za)]
  end
  % go up one level and stop
  if l == 1
   error('CGML_AMGINIT3: cannot go back on level 1')
  else
   % change the max level
   lmax=l-1;
  end
  % need to compute the Cholesky decomposition of the corasest matrix
  caa=ca{l-2};
  r=chol(caa);
  cl(lmax)={r};
  if iprint >= 1
   disp(' ')
   str=sprintf('after correction final number of levels = %g',lmax);
   disp(str)
  end
  break
 end

 % construction of coarse mesh

 if strcmp(coarse,'st')
  % standard algorithm
  [f,c,w]=cgml_coarsenstnew(a,s);
  
 elseif strcmp(coarse,'cl')
  % (modified) CLJP algorithm
  [f,c,w]=cgml_coarsencljp(a,s);
  
 elseif strcmp(coarse,'pm')
  % PMIS algorithm
  [f,c,w]=cgml_coarsenpmis(a,s);
  
 elseif strcmp(coarse,'hm')
  % HMIS algorithm
  [f,c,w]=cgml_coarsenhmis(a,s);
  
 elseif strcmp(coarse,'fa')
  % (modified) CLJP algorithm
  [f,c,w]=cgml_coarsenfalg(a,s);
  
 elseif strcmp(coarse,'mz')
  % needs M to be defined by the smoother
  % standard algorithm + check of neighbours in a
  if ~exist('m')
   m=speye(n,n);
  end
  [f,c,w]=cgml_coarsenstmz(a,m,s);

  
 elseif strcmp(coarse,'n1')
  % standard algorithm + add coarse nodes using Brandt's ideas
  if exist('pa')
   [f,c,w]=cgml_coarsenstn1(a,s,za,pa);
  else
   error('CGML_AMGINIT3: ZA is not defined, use (S)AINV as a smoother')
  end
  
 elseif strcmp(coarse,'p')
  % modifed Falgout algorithm
  [f,c,w]=cgml_coarsenp(a,s);
  
 elseif strcmp(coarse,'p1')
  % variant of the preceding one
  [f,c,w]=cgml_coarsenp1(a,s);
  
 elseif strcmp(coarse,'im')
  % coarsening using the preconditioner M
  if exist('m')
   [f,c,w]=cgml_coarsenstin(a,m,s);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 elseif strcmp(coarse,'iz')
  % coarsening using Z from AINV
  if exist('zap')
   zzt=zap+zap'-spa;
   [f,c,w]=cgml_coarsenstin(a,zzt,s);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
  
 elseif strcmp(coarse,'m2')
  % my 'm2' algorithm
  if exist('m')
   [f,c,w]=cgml_coarsenm2(a,s,m,alp);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 else
  error('CGML_AMGINIT3: this coarsening algorithm does not exist')
 end
 
 % permutation of the nodes
 p=[sort(f) sort(c)];
 cperm(l)={p};
 ap=a(p,p);
 ip=cgml_invperm(p);
 ciperm(l)={ip};
 dimf=length(f);
 dimc=length(c);
 
 % construction of the interpolation matrix
 itp=0;
 
 if strcmp(interpo,'st')
  % standard AMG interpolation
  weight=cgml_winterp(a,s,f,c,w);
  
 elseif strcmp(interpo,'sc')
  % Schur interpolation
  if exist('m')
   mp=m(p,p);
   weight=-mp(1:dimf,1:dimf)*ap(1:dimf,dimf+1:n);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 elseif strcmp(interpo,'im')
  % interpolation using the approximate inverse M
  if exist('m')
   weight=cgml_wintinv(m,f,c,w);
  else
   error('CGML_AMGINIT3: M is not defined for this smoother')
  end
  
 elseif strcmp(interpo,'iz')
  % interpolation using Z
  if exist('zap')
   zzt=zap+zap'-spa;
   weight=cgml_wintinv(zzt,f,c,w);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
  
 elseif strcmp(interpo,'em')
  % energy minimization interpolation (Wan and Chan like)
  itp=1;
  prol=cgml_enermin(a,f,c);
  prol=prol(p,:);
  
 elseif strcmp(interpo,'ez')
  % energy minimization using Z (?)
  itp=1;
  if exist('zap')
   zzt=zap+zap'-spa;
   prol=cgml_enermin(zzt,f,c);
   prol=prol(p,:);
  else
   error('CGML_AMGINIT3: ZAP is not defined for this smoother')
  end
  
 elseif strcmp(interpo,'wi')
  % Wagner like interpolation with minimization
  if exist('sm')
   weight=cgml_wagint(a,s,sm,f,c,w);
  else
   error('CGML_AMGINIT3: SM is not defined for this smoother')
  end
  
 elseif strcmp(interpo,'wm')
  % my algorithm (with neighbours of neighbours)
  weight=cgml_wmeur(a,f,c,w);
  
 else
  error('CGML_AMGINIT3: this interpolation algorithm does not exist')
 end
 
 % store the fine and coarse nodes and the interpolation weights
 cf(l)={f};
 cc(l)={c};
 cw(l)={w};
 cdf(l)={length(f)};
 
 % interpolation (prolongation) matrix prol
 % identity on the coarse nodes
 if itp == 0
  
  % Jacobi improvement of interpolation?
  % this corresponds to long range interpolation
  % it increases the complexity of the coarse matrices
  jac=0;
  if jac == 1
   Aff=ap(1:dimf,1:dimf);
   Dff=diag(1./diag(Aff));
   Afc=ap(1:dimf,dimf+1:end);
   njac=1;
   for jj=1:njac
    weight=(speye(dimf)-Dff*Aff)*weight-Dff*Afc;
   end
  end
   
  prol=[weight ; speye(dimc,dimc)];
 end
 % store the interpolation matrix
 cp(l)={prol};
 % restriction matrix (needs to be symmetric for CG)
 res=prol';
 cr(l)={res};
 
 %spy(prol)
 %title('prol')
 %pause
 
 % construction of the coarse matrix (next level)
 % always use Galerkin
 a=res*ap*prol;
 
 spy(a)
 pause
 
 if normal ==1
  % normalize on all levels
  [a,da]=cgml_normaliz(a);
 end
 
 % compute an estimate of the condition number with Lanczos
 %[lmin,lmaxx,se]=lancz(a,50);
 %if abs(lmin) > 0
 % kap_of_next_A=lmaxx/lmin
 %end
 %spy(a)
 %title('coarse matrix')
 %pause
 
 % store the next matrix
 ca(l)={a};
 
 if normal == 1
  % store the normalizing factor
  cda(l+1)={da};
 end
 
 nn=length(c);
 % Do we have enough differences in the sizes of the grids?
 %if (nnold-nn)/nnold <= 0.2
 %if (nnold-nn)/nnold <= 0.1
 if (nnold-nn)/nnold <= 0.05
  if iprint >= 1
   disp(' not enough difference')
   [nnold nn]
  end
  % not enough difference of number of nodes between two consecutive levels
  % stop the recursion and solve exactly
  lmax=l;
  nnold=nn;
 else
  nnold=nn;
 end
 
end

% lmax is the number of levels
if lmax > 0
 
 % viz of the coarse grids (only for 2D grid problems)
 % for other problems comment the next line
 cgml_plotgrids1(cs,cw,lmax)
 
 stockz=0;
 stockm=0;
 for l=1:lmax
  p=cp{l};
  d=cdb{l};
  a=ca{l};
  w=cw{l};
  m=cm{l};
  z=czb{l};
  nnzn=nnz(z);
  nnzd=nnz(d);
  if strcmp(smooth,'gs') | strcmp(smooth,'po')
   nnzn=0;
   nnzd=0;
  end
  if strcmp(smooth,'tw')
   nnzd=0;
  end
  
  % viz of the AINV factor or GS or IC matrices
  %spy(z)
  
  if iprint >= 1
   % statistics
   % total storage for z and m
   stockz=stockz+nnz(z);
   stockm=stockm+nnz(m);
   totstr=totstr+nnz(a)+nnzn+nnzd+nnz(p);
   totpt=totpt+size(a,1);
   tota=tota+nnz(a);
   str=sprintf('level %g',l);
   str0=sprintf(', n=%g',size(cz{l},1));
   str1=sprintf(' storage a %g',nnna(l));
   str2=sprintf(' storage z %g',nnnz(l));
   disp(' ')
   disp([str str0])
   disp(str1)
   disp(str2)
  end
 end
 
 if iprint >= 1
  disp(' ')
  sgrid=totpt/nmax;
  sa=tota/nnza;
  str=sprintf('total storage = %g',totstr);
  str0=sprintf(', /n= %g',totstr/nmax);
  str01=sprintf(', /nnza= %g',totstr/nnza);
  str1=sprintf(', sgrid= %g',sgrid);
  str2=sprintf(', sa= %g',sa);
  disp([str str0 str01 str1 str2])
  pause
 end
 
end

