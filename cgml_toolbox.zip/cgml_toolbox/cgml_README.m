%
% Details of the parameters for CGML_PCG
%
% March 2009
%
% (a,b,x0,epss,nitmax,truer,scaling,tb,iprint,precond,
%   lmax,nu,almax,alb,smooth,influ,coarse,interp,
%    metpar,levels,metnum)
%
% a = matrix (must be symmetric positive definite)
%
% b = right hand side
%
% x0 = initial vector for PCG
%
% epss = thhreshold for convergence
%
% nitmax = maximm number of iterations
%
% truer = 1 to compute the "true" residual, 0 otherwise
%
% scaling = 1 to summetrically scale the diagonal to I, 0 otherwise
%
% tb = block size, only useful when using the block version, otherwise 1
%
% iprint = 1 to print intermediate results and summaries, 2 to print
% estimates of the error norm, 0 = no printing
%
% precond = preconditioner
%           'no' = no preconditioner
%           'sc' = diagonal
%           'ic' = Incomplete CholeskyIC(0)
%           'ch' = IC(epsilon), epsilon is the threshold
%           'lv' = IC(level), level is the number of levels
%           'sh' = shifted IC algorithm of Manteuffel using levels
%           'ss' = SSOR with omega=1
%           'po' = least squares polynomial
%           'ai' = approximate inverse AINV
%           'sa' = approximate inverse SAINV
%           'tw' =  Tang and Wan approximate inverse
%           'bc' = block incomplete Cholesky
%           'ml' = Algebraic multigrid AMG
%           'mb' = block AMG
%           'dd' = AMG with domain decomposition ordering
% 
% the input following 'precond' is:
%           = epsilon for 'ch'
%           = level for 'lv'
%           = degree for 'po'
%           = threshold for 'ai' and 'sa'
%
% For 'ml', 'mb' and 'dd' the parameters are (even though some may not be
% available for 'mb'):
%           lmax   = max number of levels
%           nu     = number of pre and post smoothing steps
%           almax  = threshold for the smoother and the influence algorithm
%           alb    = threshold for the smoother
%           smooth = smoother
%           influ  = algorithm for the computation of the influence matrix
%           coarse = coarsening algorithm
%           interp = interpolation algorithm
%           metpar = partitioning algorithm (for 'dd')
%           levels = partition of the graph into 2^levels subdomains (for 'dd')
%           metnum = reordering algorithm 'for 'dd')
%
% The choices for the smoother 'smooth' with 'ml' are:
%           'gs' = symmetric Gauss-Seidel
%           'ic' = incomplete Cholesky IC(0)
%           'ch' = IC(epsilon), epsilon is the threshold
%           'lv' = IC(level), level is the number of levels
%           'sh' = shifted IC algorithm of Manteuffel using levels
%           'po' = least squares polynomial of degree 1
%           'ai' = approximate inverse AINV
%           'sa' = approximate inverse SAINV
%           'tw' =  Tang and Wan approximate inverse
%           'gc' = conjugate gradient with a diagonal preconditioner
%           'cg' = conjuagte gradient with AINV preconditioner
%           'bj' = block Jacobi 
%
% The choices for the smoother for 'dd' are the same plus:
%           'id' = incomplete Cholesky IC(0) with dropping between subdomains
%           'cd' = incomplete Cholesky IC(epsilon) with dropping between subdomains
%           'ad' = approximate AINV with dropping between subdomains
%           'sd' = approximate SAINV with dropping between subdomains
%
% The choices for the smoother for 'mb' are:
%           'gs' = symmetric Gauss-Seidel
%           'gb' = block Gauss-Seidel
%           'ic' = incomplete Cholesky IC(0)
%           'ib' = block incomplete Cholesky
%
% The choices for the influence algorithm 'influ' are:
%           'a'  = standard algorithm (Ruge-Stuben)
%           'b'  = standard algorithm but keep at least one non-diagonal element per row of S
%           'm'  = S has the structure of the preconditioner M
%           'mi' = same as 'b' but with the preconditioner M instead of A
%           'mc' = same as 'a' but with the preconditioner M instead of A
%           'mt' = S has the structure of the preconditioner M but keep only q elements per row
%           'z'  = S has the structure of Z+Z'-D, (D,Z) from AINV
%           'zi' = same as 'b' but with Z+Z'-D instead of A
%           'zc' = same as 'a' but with Z+Z'-D instead of A
%           'zt' = S has the structure of Z+Z'-D but keep only q elements per row
%
% Only a block version of 'b' is available for 'mb'
%
% For 'dd' we have the same influence algorithms + 'o' which do nothing.
% This is useful when coarse = 'sd', 'si' or 'so' where the influence
% matrix S is computed during the coarsening process
%
% The choices for the coarsening algorithm are:
%           'st' = standard algorithm (first pass of Ruge-Stuben)
%           'cl' = modified CLJP (Cleary, Luby, Jones, Plassmann) 
%           'fa' = Falgout-like algorithm
%           'pm' = PMIS 
%           'hm' = HMIS
%           'mz' = same as 'st' + check that every F node has a C node for interpolation
%           'n1' = same as 'st' + add some nodes using Brandt's ideas (coded only for (S)AINV)
%           'p'  = another Falgout-like algorithm
%           'p1' = same as 'p' but refuses strong C-C connections
%           'im' = uses the preconditioner M to coarsen
%           'iz' = uses Z+Z-D from (S)AINV to coarsen
%           'm2' = uses the preconditioner M to compute the weights + standard algo
%
% For 'dd' we have also the following:
%           'sd' = standard algorithm with DD, starts by coarsening the interface
%           'si' = standard algorithm with DD, all the interface nodes are coarse
%           'so' = standard algorithm with DD with subdomain overlapping
%
% The choices for the interpolation algorithm for 'ml' and 'dd' are:
%           'st' = standard algorithm 
%           'sc' = Schur algorithm
%           'im' = uses the inverse of the preconditioner to interpolate
%           'iz' = uses Z+Z'-D from (S)AINV to interpolate
%           'em' = energy minimization interpolation (Chan and Wan)
%           'wi' = Wagner like interpolation with minimization
%           'wm' = distance 2 interpolation
%
% Only 'st' interpolation is available for 'mb'
%
% The other parameters only make sense for 'dd'
%  metpar: partitioning algorithm
%           'r'  = Reverse Cuthill-McKee (RCM) 
%           's'  = Spectral partitioning
%           'i'  = Inertial (geometric) partitioning (works only for the unit square)
%
%  levels: 2^levels subdomains in the recursive partitioning
%
%  metnum: reordering for the subdomains
%           'md' = (approximate) minimum degree algorithm
%           'rc' = Reverse Cuthill-McKee
%           'no' = no reordering
%
%
%