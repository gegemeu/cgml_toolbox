function []=cgml_plotgridsp(cs,cw,cnosd,lmax,perm,nbsd);
%CGML_PLOTGRIDSP plot the mg coarse meshes on the graph
% for a square mesh with a permutation
% nbsd subdomains
% w=-100 coarse point
%
% Author G. Meurant, June 2001
%
% fine grid
n=size(cs{1},1);
xy=gmesh(sqrt(n));
xy=xy(perm,:);
xw=xy;
gplot(cs{1},xy)
pause
pcolor=['y';'m';'c';'r';'g';'b'];
% go down the grids
for l=1:lmax-1
 gplot(cs{l},xw)
 hold on
 w=cw{l};
 nos=cnosd{l};
 nosd=nos+1;
 ind=find(w == -100);
 xz=xw;
 if length(ind) > 0
  xw=xw(ind,:);
  nos1=nos(ind);
  nosd=rem(nosd(ind),5)+1;
  plotsqc(xw(:,1),xw(:,2),pcolor(nosd))
  ind0=find(nos1 == 0);
  if length(ind0) ~= 0
   xw0=xw(ind0,:);
   s0=size(xw0,1);
   pcol(1:s0)='k';
   plotsqc(xw0(:,1),xw0(:,2),pcol(1:s0))
  end
 end
 ind=find(w ~= -100);
 if length(ind) > 0
  nos1=nos(ind);
  xz=xz(ind,:);
  sz=size(xz,1);
  pcol(1:sz)='w';
  plotsqc(xz(:,1),xz(:,2),pcol(1:sz))
  ind0=find(nos1 == 0);
  if length(ind0) ~= 0
   xw0=xz(ind0,:);
   s0=size(xw0,1);
   pcol(1:s0)='k';
   %plotsqc(xw0(:,1),xw0(:,2),pcol(1:s0))
  end
 end
 tit=['l = ' num2str(l+1) ', nb of coarse points = ' num2str(length(xw))];
 title(tit)
 pause
 hold off
end
hold off
