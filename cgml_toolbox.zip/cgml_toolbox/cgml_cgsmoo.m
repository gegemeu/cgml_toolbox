function x=cgml_cgsmoo(a,l,d,b,x0,nu);
%CGML_CGSMOO conjugate gradient smoothing with AINV preconditioner 
%
% rhs b
% the preconditioner is
% m^-1=l d l^T (ex: Benzi sparse inverse)
%
% Author G. Meurant
% Aug 2000
%

x=x0;
r=b-a*x;
y=l'*r;
z=l*(d.*y);
p=z;
rtr=z'*r;

for ll=1:nu
 ap=a*p;
 alp=rtr/(p'*ap);
 x=x+alp*p;
 r=r-alp*ap;
 y=l'*r;
 z=l*(d.*y);
 rk=r'*r;
 rtrz=z'*r;
 bet=rtrz/rtr;
 rtr=rtrz;
 p=z+bet*p;
end


