function [f,c,w]=cgml_coarsenfalg(a,s);
%CGML_COARSENFALG Falgout coarsening algorithm, find the fine and coarse nodes
%
% s is an influence matrix for a
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w are the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%
% author G. Meurant
% Mar 2009
%

f=[];
c=[];
n=size(s,1);

% modified weights using the coloring of the graph
%w=cgml_wght_cljp(a,s);
% usual random weights
w=cgml_wght_r(a,s);
dim=0;

while dim < n
 % find an independent set of nodes
 % use the coarse nodes of the result of the Ruge-Stuben algorithm
 if dim == 0
  [ff,cc,ww]=cgml_coarsenstnew(a,s);
  isn=sort(cc);
 else
  isn=cgml_ind_set(w,s);
 end

 % then use CLJP with isn as the independent set
 if length(isn) == 0
  % flag the remaining nodes as fine if not all their neighbours are fine
  ind=find(w > -50);
  indc=[];
  indf=[];
  for ii=1:length(ind)
   i=ind(ii);
   %ineighb=cgml_neighb(a,i);
   % use S instead for interpolation
   ineighb=cgml_neighb1(s,i);
   %ineighb=cgml_fmt(ineighb,[i]);
   sw=sum(w(ineighb));
   if sw == -50*length(ineighb)
    indc=[indc i];
   else
    indf=[indf i];
   end
  end
  
  w(indc)=-100;
  c=[c indc];
    
  w(indf)=-50;
  f=[f indf];
  dim=dim+length(ind);
  
 else
  % flag the nodes in the set as coarse
  w(isn)=-100;
  % c=c U {i}
  c=[c isn];
  dim=dim+length(isn);

  for ii=1:length(isn)
   i=isn(ii);
   % update the weights of the neighbours
   ind=find(s(i,:) > 0 & w > -50);
   if length(ind) > 0
    w(ind)=w(ind)-1;
    s(i,ind)=0;
   end

   ind=find(s(:,i) > 0 & w' > -50);
   if length(ind) > 0
    for jj=1:length(ind)
     j=ind(jj);
     s(j,i)=0;
     indi=find(s(:,j) > 0 & w' > -50);
     if length(indi) > 0
      for kk=1:length(indi)
       k=indi(kk);
       if s(k,i) > 0
        if w(j) > -50
         w(j)=w(j)-1;
        end
        s(k,j)=0;
       end % if
      end % for k
     end % if
    end % for j
   end % if

   % if the modified weights are zero flag the nodes as fine
   ind=find(w <= 1 & w > -50);
   if length(ind > 0)
    w(ind)=-50;
    f=[f ind];
    dim=dim+length(ind);
   end

  end % for i
 end % if isn

end % while





