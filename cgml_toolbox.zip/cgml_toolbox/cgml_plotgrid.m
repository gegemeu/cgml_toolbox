function []=cgml_plotgrid(cs,cw);
%CGML_PLOTGRID plot the AMG coarse meshes on the graph for a square mesh
%
% w=-100 coarse point
%
% Author G. Meurant, Aug 2001
%
% fine grid
n=size(cs,1);
xy=gmesh(sqrt(n));
xw=xy;
gplot(cs,xw)

hold on
w=cw;
xz=xw;
ind=find(w == -100);
if length(ind) > 0
 xw=xw(ind,:);
 plotsq(xw(:,1),xw(:,2))
end
ind=find(w ~= -100);
if length(ind) > 0
 xz=xz(ind,:);
 plotsqg(xz(:,1),xz(:,2))
end
tit=['nb of (red) coarse points = ' num2str(length(xw))];
title(tit)
hold off