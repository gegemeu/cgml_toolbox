function ind=cgml_neighbset(a,i,k);
%CGML_NEIGHBSET set of the nodes which are at distance k of node i 
% in the graph of matrix a
%
% k=0 neighbors of i
% k=1 neighbors + neighbors of neighbors 
% etc...
%
% Author G. Meurant
% Sept 2000
 
ind=cgml_neighboset(a,i,k,i);
ind=cgml_compr(ind);