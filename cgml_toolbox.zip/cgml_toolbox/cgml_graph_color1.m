function [ncolor,color]=cgml_graph_color1(a);
%CGML_GRAPH_COLOR1 colors the graph of a
%
% 2 nodes which are linked in the graph of a must not have the same color
% IDO algorithm (see Jones and Plassmann)
% this is a sequential algorithm
%
% ncolor = number of colors
% color  = color of the nodes of the graph
%
% Author G. Meurant
% Mar 2009
%

tic

n=size(a,1);
color=zeros(n,1);

ncolor=1;
color(1)=1;
% color the first node
% colors already used
colors=[1];
% number of colored nodes
ncol=1;
% front of nodes with uncolored neighbours
front=[1];

while ncol < n
 % find the neighbours of the already colored nodes (in the front) with uncolored neighbours
 nfront=length(front);
 indcol=[];
 for jj=1:nfront
  j=front(jj);
  ind=cgml_neighb1(a,j);
  list=find(color(ind) == 0);
  %indcol=cgml_compr([indcol ind(list)]);
  indcol=unique([indcol ind(list)]);
 end
 indcol=sort(indcol);

 maxk=0;
 maxdeg=0;
 % for all the neighbours
 for kk=1:length(indcol);
  k=indcol(kk);
  % find the number of neighbours to which k is connected in the set
  % of already colored nodes
  indk=cgml_neighb1(a,k);
  %deg=cgml_fmt(color(indk),[0]);
  deg=cgml_setdiff(color(indk),[0]);
  deg=length(deg);
  if deg > maxdeg
   maxdeg=deg;
   maxk=k;
  end
 end % for k

 % choose the node in ind with the maximum number of adjacent nodes
 % the winner is maxk;
 % give it the smallest available color
 % colors of the neighbours of maxk
 indk=cgml_neighb1(a,maxk);
 %colk=cgml_compr(color(indk));
 colk=unique(color(indk));
 %colk=cgml_fmt(colk,[0]);
 colk=cgml_setdiff(colk,[0]);
 if length(colk) == ncolor
  % all the previous colors are used, use a new one
  ncolor=ncolor+1;
  color(maxk)=ncolor;
  colors=[colors ncolor];
  ncol=ncol+1;
 else
  % find the smallest available color
  %acol=cgml_fmt(colors,colk);
  acol=cgml_setdiff(colors,colk);
  acol=sort(acol);
  color(maxk)=acol(1);
  ncol=ncol+1;
 end
 
 % add maxk to the front and see if there are nodes to remove
 front=[front maxk];
 % check if all the neighbours are colored
 rem=[];
 for kk=1:length(front)
  k=front(kk);
  % get the neighbours of k
  indk=cgml_neighb1(a,k);
  co=color(indk);
  ico=find(co == 0);
  if length(ico) == 0
   % all the neighbours are colored, remove k from the front
   rem=[rem k];
  end % if
 end % for kk
 % physically remove the nodes
 %front=cgml_fmt(front,rem);
 front=cgml_setdiff(front,rem);
   
end % while

toc
str=sprintf(' nb of colors = %g',ncolor);
disp(str)



