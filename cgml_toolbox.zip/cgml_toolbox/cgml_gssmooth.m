function x=cgml_gssmooth(a,b,x0,nu);
%CGML_GSSMOOTH Gauss Seidel smoothing for AMG
%
% nu iterations starting from x0
%
% Author G. Meurant
% Aug 2000
%

n=size(a,1);
x=x0;
dl=tril(a);
lt=a-dl;

for i=1:nu
 x=dl\(b-lt*x);
end

