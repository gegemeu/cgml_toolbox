function [d,l,d1,ld,ldd]=cgml_initprecb(a,precond,tb,iprint,param);
%CGML_INITPRECB computes many preconditioners for CG
% point and block preconditioners (except multilevel)
%
% a - matrix
% precond - type of preconditioning
%  ='no' M=I
%  ='sc' diagonal
%  ='ic' IC(0)
%  ='ch' IC(epsilon)
%  ='lv' IC(level)
%  ='sh' shifted alg of Manteuffel using levels
%  ='ss' SSOR with omega=1
%  ='po' least squares polynomial
%  ='ai' AINV
%  ='sa' SAINV
%  ='tw' Tang and Wan approximate inverse
%  ='bc' block Incomplete Cholesky
% tb - block size
% param - parameter needed by some preconditioners
%  = nothing for 'no', 'ss' and 'ic'
%  = epsilon for 'ch'
%  = level for 'lv' and 'ei'
%  = degree of polynomial for 'po'
%  = tau for 'ai'
%  = nothing for 'tw'
%  = number of levels for 'ml'
% 
%
% output (depends on precond)
%  for incomplete factorizations or AINV
%   l - lower triangular factor
%   d - inverse of the diagonal matrix (to multiply the rhs)
%   d1 - square root of the diagonal (or its inverse) for accuracy estimates
%   ld - l sqrt(d) or l sqrt(1/d)
%   ldd - inf norm of the inverse of l sqrt(d)
% for least squares polynomial
%   l - empty
%   d - coefficients of the polynomial and max min Gerschgorin bounds
%
% Author G. Meurant
% Feb 2001
%

n=size(a,1);
ee=ones(n,1);

switch precond
 
case 'no'
 % no preconditioning
 d=ones(n,1);
 d1=d;
 l=speye(n);
 ld=1;
 ldd=1;
 
case 'sc'
 % diagonal preconditioning
 d=diag(a);
 d1=d;
 l=speye(n);
 ld=1;
 ldd=max(1./sqrt(d));
 
case 'ss'
 %  SSOR = L D^{-1} L^T with D diag of a (omaga = 1)
 l=tril(a);
 d=diag(a);
 d1=sqrt(1./d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 
case 'bc'
 % Incomplete block Cholesky
 [d,l,d1]=cgml_icbopt(a,tb);
 ld=1;
 ldd=1;

case 'ic'
 % Incomplete point Cholesky with the same structure as a
 % computes L D L^T with diag(L)=1
 % send back D^{-1}
 b=a;
 for k=1:n-1
  m=size(b,1);
  %l(k+1:n,k)=b(2:m,1)/b(1,1);
  %l=sparse(l);
  % dropping strategy
  %for i=k+1:n
  % if a(i,k) == 0
  %  l(i,k)=0;
  % end
  %end
  b1=1/b(1,1);
  i=find(a(k:n,k));
  sl=sparse(i,1,b(i,1)*b1,m,1);
  l(k:n,k)=sl;
  l(k,k)=1;
  d(k)=b(1,1);
  % Schur complement
  %b=b(2:m,2:m)-b(1,1)*l(k+1:n,k)*l(k+1:n,k)';
  ind=i(2:end)-1;
  sl=sl(2:m);
  bb=b(2:m,2:m);
  % do not take care of symmetry (faster)
  for i=ind
   bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
  end
  b=bb;
 end
 l(n,n)=1;
 d(n)=b(1,1);
 ind=find(d<=0);
 if length(ind) > 0
  error('CGML_INITPRECB: Pb with the incomplete factorization, negative diag elts')
 end
 d=d';
 d1=sqrt(d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 d=1./d;
 
case 'ch'
 % Incomplete point Cholesky keeping some fill-in
 % same factorization as the previous one
 epsdrop=param;
 b=a;
 %
 % norm of each row of a
 %
 for i=1:n
  anorm(i)=norm(a(i,:), inf);
 end
 for k=1:n-1
  m=size(b,1);
  b1=1/b(1,1);
  ii=find(b(:,1));
  sl=sparse(ii,1,b(ii,1)*b1,m,1);
  l(k:n,k)=sl;
  %
  % dropping strategy
  %
  % for i=k+1:n
  %  if abs(l(i,k)) <= epsdrop*anorm(i)
  %   l(i,k)=0;
  %  end
  % end
  i=find(abs(l(k+1:n,k))./anorm(k+1:n)'<=epsdrop);
  l(i+k,k)=zeros(length(i),1);
  l(k,k)=1;
  d(k)=b(1,1);
  % Schur complement
  ind=find(l(k+1:n,k))';
  sl=sl(2:m);
  bb=b(2:m,2:m);
  %b=b(2:m,2:m)-b(1,1)*l(k+1:n,k)*l(k+1:n,k)';
  for i=ind
   bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
  end
  b=bb;
 end
 l(n,n)=1;
 d(n)=b(1,1);
 ind=find(d<=0);
 if length(ind) > 0
  error('CGML_INITPRECB: Pb with the incomplete factorization, negative diag elts')
 end
 d=d';
 d1=sqrt(d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 d=1./d;
 
case 'lv'
 % Incomplete point Cholesky with levels
 % same factorization of the previous one
 levmax=param;
 b=a;
 levm=100;
 lev=spones(a);
 for k=1:n-1
  m=size(b,1); 
  b1=1/b(1,1);
  ii=find(b(:,1));
  sl=sparse(ii,1,b(ii,1)*b1,m,1);
  l(k:n,k)=sl;
  % dropping strategy
  %j=2;
  %for i=k+1:n
  % if lev(j,1) > levmax
  %  l(i,k)=0;
  %  lev(j,1)=levm;
  % end
  % j=j+1;
  %end
  i=find(lev(2:end,1)>levmax);
  l(i+k,k)=zeros(length(i),1);
  lev(i+1,1)=levm*ones(length(i),1);
  l(k,k)=1;
  d(k)=b(1,1);
  % Schur complement
  level=lev;
  %b=b(2:m,2:m)-b(1,1)*l(k+1:n,k)*l(k+1:n,k)';
  ind=find(l(k+1:n,k))';
  sl=sl(2:m);
  bb=b(2:m,2:m);
  lev=level(2:m,2:m);
  % do not take care of symmetry (faster)
  for i=ind
   bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
   j=find(b(i+1,:)~=0)-1;
   indj=cgml_fmt(ind,j);
   ll=level(i+1,1);
   lev(i,indj)=ll+level(indj+1,1)';
  end
  b=bb;
 end
 l(n,n)=1;
 d(n)=b(1,1);
 ind=find(d<=0);
 if length(ind) > 0
  error('CGML_INITPRECB: Pb with the incomplete factorization, negative diag elts')
 end
 d=d';
 d1=sqrt(d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 d=1./d;
 
case 'sh'
 % Incomplete point Cholesky of Manteuffel (Eijkhout) with levels
 % L inv(D) L^T with diag(L)=D
 levmax=0;
 if iprint >= 1
  [lu,bdown] = cgml_miluk(a,levmax,3,iprint);
 else
  [lu,bdown] = cgml_miluk(a,levmax,3);
 end
 l=tril(lu);
 d=diag(l);
 ind=find(d<=0);
 if length(ind) > 0
  disp('CGML_INITPRECB: Pb with the incomplete factorization, negative diag elts')
 end
 d1=sqrt(1./d);
 ls=l*spdiags(d1,0,n,n);
 ld=normest(ls);
 w=ls\ee;
 ldd=max(abs(w));
 
case 'po'
 % least squares polynomial of degree k
 k=param;
 if isempty(k)
  k=1;
 end
 % compute the Gerschgorin bounds
 un=ones(n,1);
 aa=abs(a);
 da=spdiags(diag(aa),0,n,n);
 % put zeros on the diagonal
 aa=spdiags(zeros(n,1),0,aa);
 b=(da-aa)*un;
 bb=(da+aa)*un;
 lmin=min(b);
 lmax=max(bb);
 s=zeros(k+2,1);
 mu0=-(lmin+lmax)/(lmax-lmin);
 s(1)=1/sqrt(pi);
 s(2)=sqrt(2/pi)*(lmin+lmax)/(lmin-lmax);
 s(3)=sqrt(2/pi)*((2*(lmin+lmax)^2/(lmin-lmax)^2)-1);
 for j=4:k+2
  s(j)=2*mu0*s(j-1)-s(j-2);
 end
 d=s;
 d(k+3)=lmin;
 d(k+4)=lmax;
 l=[];
 d1=speye(n);
 ld=1;
 ldd=1;
 
case 'ai'
 % AINV approximate inverse of Benzi and Tuma
 tau=param;
 if isempty(tau)
  tau=0.1;
 end
 [l,d]=cgml_ainvn1(a,tau);
 nnzl=nnz(l)
 ind=find(d<=0);
 if length(ind) > 0
  error('CGML_INITPRECB: Pb with the AINV approximate inverse, negative diag elts, try SAINV')
 end
 dd=sqrt(d);
 d1=sqrt(1./d);
 ls=l*spdiags(dd,0,n,n);
 ld=1;
 ldd=norm(ls,inf);
 
case 'sa'
 % SAINV approximate inverse of Benzi and Tuma
 tau=param;
 [l,d]=cgml_sainvn1(a,tau);
 ind=find(d<=0);
 if length(ind) > 0
  error('CGML_INITPRECB: Pb with the SAINV approximate inverse, negative diag elts')
 end
 dd=sqrt(d);
 d1=sqrt(1./d);
 ls=l*spdiags(dd,0,n,n);
 ld=1;
 ldd=norm(ls,inf);
 
case 'tw'
 % Tang and Wan approximate inverse
 l=cgml_saitw(a,0,1);
 d1=ones(n,1);
 d=d1;
 ld=1;
 ldd=1;
 
otherwise
 error('CGML_INITPRECB: this preconditioner does not exist')
end
