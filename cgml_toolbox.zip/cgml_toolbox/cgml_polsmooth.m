function x=cgml_polsmooth(a,m,b,x0,nu,lmin,lmax);
%CGML_POLSMOOTH  Richardson smoothing with polynomial precond
%
% nu iterations
%
% Author G. Meurant
% Sept 2000
%

x=x0;

for i=1:nu
 r=b-a*x;
 z=cgml_evmcarre(a,r,m,lmin,lmax);
 x=x+z;
end

