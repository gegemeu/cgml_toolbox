function [z,p]=cgml_sainvn2(a,epss,q);
%CGML_SAINVN2 sparse approximate inverse of Benzi and Tuma (SISSC 97), stabilized version of cgml_ainvn2
%
% we keep only the q largest elements of each column
% return the inverse of the diagonal
%
% author G. Meurant
% March 2002
%

n=size(a,1);
z=speye(n);
p=zeros(n,1);
anorm=epss*max(abs(a'))'; % for dropping

for i=1:n-1
 xold=z(:,i);
 xold(i)=0;
 x=abs(z(1:i-1,i));
 if size(x,1) ~= 0
  ind=find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  z(ind,i)=0;
  % keep only the q largest elements
  [x,indx]=sort(abs(z(1:i-1,i)));
  qq=min(q,i-1);
  indl=indx(1:i-1-qq);
  z(indl,i)=0;
  x=abs(z(:,i));
  if nnz(x) == 1
   % there is just a diagonal element
   % keep also the largest non diagonal element
   [maxold,iold]=max(abs(xold));
   z(iold(1),i)=xold(iold(1));
  end
 end
 %p(i:n)=a(i,:)*z(:,i:n);
 v=a*z(:,i);
 p(i:n)=v'*z(:,i:n);
 p1=1/p(i);
 indp=find(abs(p(i+1:n)) > 0)+i;
 for j=indp'
  z(:,j)=z(:,j)-p(j)*p1*z(:,i);
 end
end

% last column
xold=z(:,n);
xold(n)=0;
for j=1:n-1
 x=abs(z(j,n));
 if x < anorm(j) & x > 0
  z(j,n)=0;
 end
end
[x,indx]=sort(abs(z(1:n-1,n)));
qq=min(q,n-1);
indl=indx(1:n-1-qq);
z(indl,n)=0;
x=abs(z(:,n));
if nnz(x) == 1
 % keep the largest non diagonal element
 [maxold,iold]=max(abs(xold));
 z(iold(1),n)=xold(iold(1));
end
%p(n)=a(n,:)*z(:,n);
p(n)=z(:,n)'*a*z(:,n);
p=1./p;
