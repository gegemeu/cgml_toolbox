function l=cgml_trilb(a,tb);
%CGML_TRILB block lower triangular part of a with blocks of order tb
%
% Author G. Meurant
% August 2006
%

l=a;
n=size(a,1);
ntb=n/tb;

for I=1:ntb
  ideb=(I-1)*tb+1;
  jdeb=ideb+tb;
  l(ideb:ideb+tb-1,jdeb:n)=0;
end
