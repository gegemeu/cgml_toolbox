function isn=cgml_ind_set(w,s);
%CGML_IND_SET finds an independent set 
%
% {i: w(i) > w(j) for all j in S_i U S_i^T}
%
% Author G. Meurant
% Mar 2009
%

isn=[];
n=size(s,1);
% this is probably not needed
s=s-diag(diag(s));

for i=1:n
 if w(i) > -50
  indi=find(s(:,i) > 0 & w' > -50);
  indit=find(s(i,:) > 0 & w > -50);
  ind=unique([indi(:)' indit(:)']);
  if length(ind) > 0
   maxw=max(w(ind));
  else
   maxw=realmax;
  end
  if w(i) > maxw
   isn=[isn i];
  end
 end
end



