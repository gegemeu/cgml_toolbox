function [f,c,w]=cgml_coarsenstloc2(a,s,w,l);
%CGML_COARSENSTLOC2 find the fine and coarse nodes standard AMG algorithm 
%
% s is an influence matrix 
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%  do not use the second pass
% some nodes may have already been defined
% refuse F-F connections only on level 1
%
% author G. Meurant
% March 2002
%

% find the nodes which are already labelled
f=find(w == -50);
c=find(w == -100);

if nnz(s) == 0
 % S is empty
 ind=find(w > 0);
 w(ind)=-100;
 c=[c ind];
 return
end

n=size(s,1);
dim=length(f)+length(c);

% first pass of standard algorithm (see Wagner)
while dim < n
 [y,i]=max(w);
 w(i)=-100;
 % c=c U {i}
 c=[c i];
 dim=dim+1;
 
 % flag the influences as F points
 % except if this introduces an F-F connection
 ind=find(s(:,i) > 0 & w' > -50);
 %w(ind)=-50;
 %dim=dim+length(ind);
 %f=[f ind'];
 
 % find the points which influences the new F points
 % for all j in ind
 for j=ind'
  indk=find(s(:,j) >0 & w' == -50);
  if length(indk) == 0 | l > 1
   % no fine node in the neighborhood or l > 1, flag j as fine
   w(j)=-50;
   dim=dim+1;
   f=[f j];
   indk=find(s(:,j) >0 & w' > -50);
   % increase their weight
   w(indk)=w(indk)+1;
  else % flag as coarse
   w(j)=-100;
   dim=dim+1;
   c=[c j];
  end % if length
 end % for j
 
 % decrease the weight of the nodes which are influenced by i
 ind=find(s(i,:) > 0 & w > -50);
 w(ind)=w(ind)-1;
end

dimf=length(f);



