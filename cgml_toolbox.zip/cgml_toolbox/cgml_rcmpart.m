function [part1,part2,sep1,sep2,svert] = cgml_rcmpart(A,xy,ignore);
%CGML_RCMPART partition of a graph from a Reverse Cuthill-McKee matrix reordering
%
%                 returns a partition of the n vertices
%                 of A into two lists part1 and part2 according to the
%                 RCM ordering obtained by the symrcm MATLAB routine
%
% [part1,part2,sep1,sep2] = rcmpart(.) also returns the separating edges
%
% [part1,part2,sep1,sep2,svert] = rcmpart(.) returns the separating vertices
%
% If vertex coordinates are given as a second argument,
% rcmpart(A,xy) draws a picture of the result
%
% Pierre LECA
% June 98 (inspired by the J.GILBERT package)
%

if nargin < 2
 xy = 0;
end
picture = max(size(xy)) > 1;

p=symrcm(A);
S=spones(A(p,p));
sum_row=sum(S);
moy_part=nnz(S)/2.;

val=nnz(S);
irow=size(sum_row,2);
while val > moy_part
 val=val-sum_row(irow);
 irow=irow-1;
end

part1 = p(irow+1:size(S,1));
part2 = p(1:irow);

if nargout > 2 | picture
 [sep1,sep2] = find(A(part1,part2));
 sep1 = part1(sep1);
 sep2 = part2(sep2);
 svert=cgml_vtxsep(A,part1,part2);
 if picture
  na_nb_ne = [length(part1) length(part2) length(sep1)];
  cgml_gplotpart(A,xy,part1);
  title('RCM Partition');
 end
end

