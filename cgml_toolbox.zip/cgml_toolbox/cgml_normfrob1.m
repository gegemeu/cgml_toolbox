function af=cgml_normfrob1(a,tb);
%CGML_NORMFROB1 returns the matrix of the Frobenius norms of the blocks of a
%
% the blocks are square of order tb
%
% Author G. Meurant
% august 2006
%
 
n=size(a,1);
% number of blocks
ntb=n/tb;
af=sparse(ntb,ntb);
% square of the elements of a
aa=a.^2;
acol=sparse(n,ntb);
% sum of aa by columns, tb columns each time
for j=1:tb
acol(:,1:ntb)=acol(:,1:ntb)+aa(:,j:tb:n-tb+j);
end
arow=sparse(ntb,ntb);
% sum of acol by rows, tb rows each time
for i=1:tb
 arow(1:ntb,:)=arow(1:ntb,:)+acol(i:tb:n-tb+i,:);
end
af=sqrt(arow);
 
