function x=cgml_amgit3(a,b,x0,nu,l,ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,cl,cda,lmax,smooth,gam,normal);
%CGML_AVMGIT3 one cycle of multi grid amg iteration with several smoothers (gs, ic or ainv)
%
% without permutation, gam=1 V cycle, gam=2 W cycle 
% b is the rhs, m (z,d) the approximate inverse smoother
% f and c are the fine and coarse nodes
% the coarse problem is solved recursively and exactly on the coarsest level
% nu is the number of pre and post smoothings steps
% matrices for each level are in cell arrays
% l=1 fine grid, l=lmax coarsest grid
% 
% Author G. Meurant
% Aug 2000
%

if normal == 1
 % normalization
 b=cda{l}.*b;
end

if l == lmax
 % corasest level, exact solve
 lt=cl{l};
 y=lt'\b;
 x=lt\y;
 if normal == 1
  x=cda{l}.*x;
 end
 return
end

% permutation
p=cperm{l};
m=cm{l};
ip=ciperm{l};
prol=cp{l};
dimf=cdf{l};

% smoother
z=cz{l};
d=cd{l};

% restriction
res=cr{l};
x=x0;

for j=1:gam
 % nu steps of pre smoothing
 
 if strcmp(smooth,'gs')
  x=cgml_sgssmooth(a,z,b,x,nu);
  
 elseif strcmp(smooth,'ga')
  x=cgml_gssmooth(a,b,x,nu);
  
 elseif strcmp(smooth,'ic')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'id')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'io')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ch')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'cd')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'lv')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ei')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'sh')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ai')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ad')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ao')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'gs')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'sa')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'sd')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'tw')
  x=cgml_saismooth(a,m,b,x,nu);
  
 elseif strcmp(smooth,'cg')
  x=cgml_cgsmoo(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'gc')
  x=cgml_cgsm(a,d,b,x,nu);
  
 elseif strcmp(smooth,'bj')
  x=cgml_cgbj(a,d,b,x,nu);
  
 elseif strcmp(smooth,'po')
  lmi=cz{l};
  lma=cd{l};
  x=cgml_polsmooth(a,m,b,x,nu,lmi,lma);
  
 elseif strcmp(smooth,'ma')
  x=cgml_matsmooth(a,m,b,x,nu);
  
 else
  error('CGML_AVMGIT3: smoother not defined')
 end
 
 r=b-a*x;
 % permute x and r
 xp=x(p);
 rp=r(p);
 
 % restrict to the next coarsest grid
 rc=res*rp;
 
 % recursively solve starting from 0
 ac=ca{l};
 x0=zeros(size(ac,1),1);
 ec=cgml_amgit3(ac,rc,x0,nu,l+1,ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,cl,cda,lmax,smooth,gam,normal);
 
 %interpolate back to the fine grid
 e=prol*ec;
 
 % add correction
 xp=xp+e;
 
 % permute x back
 x=xp(ip);
 
 % nu steps of post smoothing
 
 if strcmp(smooth,'gs')
  x=cgml_sgssmooth(a,z,b,x,nu);
  
 elseif strcmp(smooth,'ga')
  x=cgml_gssmooth(a,b,x,nu);
  
 elseif strcmp(smooth,'ic')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'id')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'io')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ch')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'cd')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'lv')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ei')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'sh')
  x=cgml_icsmooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ai')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ad')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'ao')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'gs')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'sa')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'sd')
  x=cgml_aismooth(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'tw')
  x=cgml_saismooth(a,m,b,x,nu);
  
 elseif strcmp(smooth,'cg')
  x=cgml_cgsmoo(a,z,d,b,x,nu);
  
 elseif strcmp(smooth,'gc')
  x=cgml_cgsm(a,d,b,x,nu);
  
 elseif strcmp(smooth,'bj')
  x=cgml_cgbj(a,d,b,x,nu);
  
 elseif strcmp(smooth,'po')
  lmi=cz{l};
  lma=cd{l};
  x=cgml_polsmooth(a,m,b,x,nu,lmi,lma);
  
 elseif strcmp(smooth,'ma')
  x=cgml_matsmooth(a,m,b,x,nu);
  
 else
  error('CGML_AVMGIT3: smoother not defined')
 end
end

if normal == 1
 x=cda{l}.*x;
end

