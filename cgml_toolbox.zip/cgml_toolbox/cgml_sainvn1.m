function [z,p]=cgml_sainvn1(a,epss);
%CGML_SAINVN1 sparse approximate inverse of Benzi (SISSC 97), stabilized version of ainv1
%
% Author G. Meurant
% 2001
%
 
n=size(a,1);
z=speye(n);
p=zeros(n,1);
anorm=epss*max(abs(a'))';
for i=1:n-1
 x=abs(z(1:i-1,i));
 if size(x,1) ~= 0
  ind=find(x(1:i-1) < anorm(1:i-1) & x(1:i-1) > 0);
  z(ind,i)=0;
 end
 v=a*z(:,i);
 p(i:n)=v'*z(:,i:n);
 p1=1/p(i);
 indp=find(abs(p(i+1:n)) > 0)+i;
 for j=indp'
  z(:,j)=z(:,j)-p(j)*p1*z(:,i);
 end
end
% last column
for j=1:n-1
 x=abs(z(j,n));
 if x < anorm(j) & x > 0
  z(j,n)=0;
 end
end
p(n)=z(:,n)'*a*z(:,n);
p=1./p;
 
