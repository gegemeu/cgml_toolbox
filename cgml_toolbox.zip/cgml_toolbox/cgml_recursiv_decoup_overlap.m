function [perm,nbnodes,numsd,totaloverlap,nSD,nbSD] = cgml_recursiv_decoup_overlap(levels,layers,A,met,iprint,xy)
%CGML_RECURSIV_DECOUP_OVERLAP  recursive partitioning of a graph with overlapping
%
%			The goal is to produce nbsd (2^levels) subdomains with overlap
%			The overlap depends on the numbers of layers (input parameter)
%			Splitting is done recursively using front or spectral partitioning (giving A only)
%			or inertial partitioning (giving also xy)
%
% Input:
%			levels: number of SD will be 2^levels
%			layers: layers <=0 no overlap and edges separator
%				     layers >0  overlap by sets of neighbours
%			A : the graph matrix (nodes connectivity)
%			(optionnal) xy: the nodes coordinates (geometry)
%
% Output:
%			perm: permutation numbering - subdomains first, separators at the end
%              with fill-in reduction due to call to sd_reorder
%			nbnodes(1:2^levels): the number of nodes in each subdomain or separator
%			numsd: the number of SD
%           nSD: number of the subdomain for each node
%           nbSD: number of subdomains to which a node belongs
%
% From P. Leca
% Dec 2001
%

switch met

 case 'r'
  % Reverse Cuthill_McKee partitioning
  method='cgml_rcmpart';

 case 's'
  % Spectral partitioning
  method='cgml_specpart';
 
 case 'i'
  % Inertial partitioning (geometry)
  method='cgml_inertpart';
end

if met == 'r' | met == 's'
 if iprint > 1
  disp('CGML_RECURSIV_DECOUP_OVERLAP: splitting without coordinates');
 end
 [maps] = cgml_dice(method,levels,A);
 
elseif met == 'i'
 if iprint > 1
  disp('CGML_RECURSIV_DECOUP_OVERLAP: splitting with coordinates');
 end
 [maps] = cgml_dice(method,levels,A,xy);
 
else
 error('CGML_RECURSIV_DECOUP_OVERLAP: wrong method')
end

maps = maps + 1;
perm = [];
nbSD=zeros(1,size(A,1));
nSD=nbSD;

numsd = 2^levels;
nbnodes = zeros(numsd,1);
totaloverlap = [];

for isd = 1:numsd
 sd_isd = find(maps == isd);
 nSD(sd_isd)=isd;
 %nbnodes(isd) = size(sd_isd,2);
 %
 [allnodes,overlap] = cgml_neighbours_by_front(layers,sd_isd,A);
 % if layers <=0 allnodes == sd_isd
 nbnodes(isd) = size(allnodes,2);
 perm =[perm,allnodes];
 nbSD(allnodes)=nbSD(allnodes)+1;
 totaloverlap = [totaloverlap,overlap];
end

tout = ones(1,size(A,1));
tout(totaloverlap) = 0;
totaloverlap = find(tout == 0);
