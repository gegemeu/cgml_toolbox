function ind=cgml_neighboset(a,i,k,ind);
%CGML_NEIGHBOSET set of the nodes which are at distance k from node i
% in the graph of matrix a
%
% k=0 neighbors of i
% k=1 neighbors + neighbors of neighbors 
% etc...
% ind is initialized to i ?
%
% Author G. Meurant
% Sept 2000
%

if k < 0
 return
elseif k == 0
 ind=[i cgml_neighb(a,i)];
elseif k > 0
 indi=[i cgml_neighb(a,i)];
 for j=indi
  ind=[ind  cgml_neighboset(a,j,k-1,j)];
 end
end
