function [ad,d]=cgml_normaliz(a);
%CGML_NORMALIZ symmetrically scales the matrix a with 1's on the diagonal
% send back the normalizing factor d in a vector
%
% Author G. Meurant
% Sept 2000
%

n=size(a,1);
d=spdiags(a,0);
d=1./sqrt(d);
dd=spdiags(d,0,n,n);
ad=dd*a*dd;
