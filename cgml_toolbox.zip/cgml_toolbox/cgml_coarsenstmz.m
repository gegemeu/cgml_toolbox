function [f,c,w]=cgml_coarsenstmz(a,m,s);
%CGML_COARSENSTMZ Standard AMG coarsening algorithm + check for M or Z
%
% s is an influence matrix computed by cgml_influst
% cgml_wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%  do not use the second pass
%
% Author G. Meurant
% Aug 2000
%

f=[];
c=[];
n=size(s,1);
w=cgml_wght(s);
dim=0;

% first pass
while dim < n
 % flag as Coarse the node with maximum weight
 [y,i]=max(w);
 w(i)=-100;
 % c=c U {i}
 c=[c i];
 dim=dim+1;
 
 % flag the influences as F points
 % 
 ind=find(s(:,i) > 0 & w' > -50);
 w(ind)=-50;
 dim=dim+length(ind);
 f=[f ind'];
 
 % find the points which influences the new F points
 % for all j in ind
 for j=ind'
  indk=find(s(:,j) >0 & w' > -50);
  % increase their value
  w(indk)=w(indk)+1;
 end
 
 % decrease the value of the nodes which are influenced by i
 ind=find(s(i,:) > 0 & w > -50);
 w(ind)=w(ind)-1;
end
dimf=length(f);

% now we check if every fine node i has a coarse node in A for standard interpolation
fold=f;
for i=fold
 [ci,indi]=cgml_coarsno(a,w,i);
 % check if there is a coarse neighbour of i in A
 if length(ci) == 0
  % if not flag i as a coarse node 
  f=cgml_setdiff(f,i);
  c=[c i];
  w(i)=-100;
 end
end
 

