function weight=cgml_wintinv(m,f,c,w);
%CGML_WINTINV computes the interpolation weights using AINV interpolation
%
% m is the approximate inverse or the factors
% f (c) is the list of the fine (coarse) nodes
% w is the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
% 
% Author G. Meurant
% Aug 2000
%

n=size(m,1);
d=zeros(n,1);
weight=sparse(n,n);

for ii=1:length(f)
 i=f(ii);
 % find the coarse neighbours in m c_i, neighbours indi
 [ci,indi]=cgml_coarsno(m,w,i);
 if length(ci) == 0
  error('CGML_WINTINV: no coarse neighbour in M')
 end
 
 % compute the sum of the entries for the coarse neighbours
 if length(ci) > 1
  d(i)=sum(abs(m(i,ci)));
  weight(i,ci)=abs(m(i,ci))/d(i);
 elseif length(ci) == 1
  weight(i,ci)=abs(m(i,ci));
 end
end

weight=sparse(weight);
p=[sort(f) sort(c)];
dimf=length(f);
wp=weight(p,p);
weight=wp(1:dimf,dimf+1:n);


