function [ci,indi]=cgml_coarsno(s,w,i);
%CGML_COARSENO find the coarse nodes and neigbours of i in s
% w = -100 for coarse nodes
%
% Author G. Meurant
% Aug 2000
%

indi=find(abs(s(i,:)) > 0);
% this is useless is is an influence matrix
indi=cgml_setdiff(indi,i);
if length(indi) ~= 0
 wi=w(indi);
 indci=find(wi == -100);
 if length(indci) ~= 0
  ci=indi(indci);
 else
  ci=[];
 end
else
 indi=[];
 ci=[];
end


