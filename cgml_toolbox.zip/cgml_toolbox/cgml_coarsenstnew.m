function [f,c,w]=cgml_coarsenstnew(a,s);
%CGML_COARSENSTNEW Standard AMG coarsening algorithm, find the fine and coarse nodes
%  
% s is an influence matrix for a
% wght computes the initial weights
% f (c) is the list of the fine (coarse) nodes
% w are the final weights for viz
% =-100 for coarse nodes, -50 for fine nodes
%  do not use the second pass
%
% author G. Meurant
% Aug 2000
%

f=[];
c=[];
n=size(s,1);

w=cgml_wght(s);
dim=0;

% first pass of standard algo (see Wagner)
while dim < n
 % flag to C the node with maximum weight
 [y,i]=max(w);
 w(i)=-100;
 % c=c U {i}
 c=[c i];
 dim=dim+1;
 
 % flag the influences of node i as F points
 ind=find(s(:,i) > 0 & w' > -50);
 w(ind)=-50;
 dim=dim+length(ind);
 f=[f ind'];
 
 % find the points (neighbours) which influence the new F points
 % for all j in ind
 for j=ind'
  indk=find(s(:,j) >0 & w' > -50);
  % increase their weights
  w(indk)=w(indk)+1;
 end
 
 % decrease the weights of nodes which are influenced by i
 ind=find(s(i,:) > 0 & w > -50);
 w(ind)=w(ind)-1;
end
 


