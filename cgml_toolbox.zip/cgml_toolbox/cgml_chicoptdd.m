function [d,l]=cgml_chicoptdd(a,nsd);
%CGML_CHICOPTDD Incomplete Cholesky decomposition of a symmetric sparse matrix, dd ordering 
%
% same structure as a, domain decomposition ordering
% drop the extra subdomain fills
% l * d * l' with d vector and l unit lower triangular
% nsd = sudomain number of the node, 0 for interfaces
% optimized version 
%
% Author G. Meurant
% March 2001
%
 
n=size(a,1);
b=a;

for k=1:n-1
 m=size(b,1);
 %l(k+1:n,k)=b(2:m,1)/b(1,1);
 %l=sparse(l);
 % dropping strategy
 %for i=k+1:n
 % if a(i,k) == 0
 %  l(i,k)=0;
 % end
 %end
 b1=1/b(1,1);
 i=find(a(k:n,k));
 sl=sparse(i,1,b(i,1)*b1,m,1);
 % drop extra subdomains fill
 nsdk=nsd(k:n);
 sl=cgml_zerodd(1,sl,nsdk);
 l(k:n,k)=sl;
 l(k,k)=1;
 d(k)=b(1,1);
 % Schur complement
 %b=b(2:m,2:m)-b(1,1)*l(k+1:n,k)*l(k+1:n,k)';
 ind=i(2:end)-1;
 sl=sl(2:m);
 bb=b(2:m,2:m);
 % do not take care of symmetry (faster)
 for i=ind
   bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
 end
 b=bb;
end
l(n,n)=1;
d(n)=b(1,1);
d=d';
