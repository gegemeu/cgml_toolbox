function s=cgml_influstb(a,alp);
%CGML_INFLUSTB influence matrix of a standard AMG choice
%
% computes a sparse matrix s of ones where
% |a(i,j)| >= alp * max_i |a(i,k)|
% keep at least one element per row
%
% author G. Meurant
% Aug 2000
%
 
maxs=max(abs(a'))';
a=a-diag(diag(a));
if nnz(a) == 0
 disp('CGML_INFLUSTB: A is diagonal')
 s=spones(a);
 return
end

n=size(a,1);
s=sparse(n,n);

for i=1:n
 ind= find(abs(a(i,:)) >= alp*maxs(i));
 if length(ind) == 0 
  [y,j]=max(abs(a(i,:)));
  if y > 0
   ind=j;
  else
   ind=[];
  end
 end
 if length(ind) > 0
  s(i,ind)=spones(ind);
 end
end
%s=s-diag(diag(s));
if nnz(s) == 0
 error('CGML_INFLUSTB: influstb, s is empty!')
end
