function x=cgml_amgit3b(a,b,x0,nu,l,ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,cl,cda,lmax,smooth,gam,normal,tb);
%CGML_AMGIT3B one cycle of  block multi grid AMG iteration with several smoothers (gs, ic)
%
% without permutation, gam=1 V cycle, gam=2 W cycle 
% b is the rhs, m (z,d) the approximate inverse smoother
% f and c are the fine and coarse nodes
% the coarse problem is solved recursively and exactly on the coarsest level
% nu is the number of pre and post smoothings steps
% matrices for each level are in cell arrays
% l=1 fine grid, l=lmax coarsest grid
% 
% Author G. Meurant
% Aug 2000
%

if normal == 1
 % normalization
 b=cda{l}.*b;
end

if l == lmax
 % coarsest level, exact solve
 lt=cl{l};
 y=lt'\b;
 x=lt\y;
 if normal == 1
  x=cda{l}.*x;
 end
 return
end

% permutation
p=cperm{l};
m=cm{l};
ip=ciperm{l};
prol=cp{l};
dimf=cdf{l};

% smoother
z=cz{l};
d=cd{l};

% restriction
res=cr{l};

x=x0;
for j=1:gam
 
 % nu steps of pre smoothing
 if smooth == 'gb'
  x=cgml_sgssmoothb(a,z,b,x,nu,tb);
  
 elseif smooth == 'gn'
  x=cgml_sgssmoothn(a,z,b,x,nu,tb);
  
 elseif smooth == 'gs'
  x=cgml_sgssmooth(a,z,b,x,nu);
  
elseif smooth=='ib'
  x=cgml_icsmoothb(a,z,d,b,x,nu);
  
 else
  error('CGML_AMGIT3B: smoother not defined')
 end
 
 r=b-a*x;
 % permute x and r
 xp=x(p);
 rp=r(p);
 
 % restrict to the coarse grid
 rc=res*rp;
 
 % recursively solve starting from 0
 ac=ca{l};
 x0=zeros(size(ac,1),1);
 ec=cgml_amgit3b(ac,rc,x0,nu,l+1,ca,cm,cp,cr,cperm,ciperm,cdf,cz,cd,cl,cda,lmax,smooth,gam,normal,tb);
 
 %interpolate back to the fine grid
 e=prol*ec;
 
 % add correction
 xp=xp+e;
 
 % permute x back
 x=xp(ip);
 
 % nu steps of post smoothing
 if smooth == 'gb'
  x=cgml_sgssmoothb(a,z,b,x,nu,tb);
  
elseif smooth == 'gn'
  x=cgml_sgssmoothn(a,z,b,x,nu,tb);
  
 elseif smooth == 'gs'
  x=cgml_sgssmooth(a,z,b,x,nu);
  
 elseif smooth=='ib'
  x=cgml_icsmoothb(a,z,d,b,x,nu);
  
 else
  error('CGML_AMGIT3B: smoother not defined')
 end
end

if normal == 1
 x=cda{l}.*x;
end

