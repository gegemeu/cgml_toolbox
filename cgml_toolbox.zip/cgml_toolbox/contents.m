%
% Contents of CGML_TOOLBOX
%
% Conjugate Gradient with Algebraic MultiGrid (AMG) preconditioners and more...
%
%
% CGML_AINVN1 sparse approximate inverse AINV of Benzi and Tuma (SISSC 97)
% CGML_AINVN2 sparse approximate inverse of Benzi and Tuma (SISSC 97), keep q largest elements
% CGML_AINVN4 sparse approximate inverse of Benzi and Tuma (SISSC 97), computes two decompositions
% CGML_AINVN4DD1 sparse approximate inverse of Benzi and Tuma (SISSC 97)
% CGML_AISMOOTH AINV Richardson smoothing for AMG
% CGML_AMGINIT3 init of multi level preconditioner
% CGML_AMGINIT3B init of block multi level iteration
% CGML_AMGINIT4DD init of multi level iteration with domain decomposition ordering
% CGML_AVMGIT3 one cycle of multi grid AMG iteration with several smoothers (gs, ic or ainv)
% CGML_AMGIT3B one cycle of  block multi grid AMG iteration with several smoothers (gs, ic)
% CGML_CGBJ conjugate gradient smoothing with block diagonal preconditioner
% CGML_CGSM conjugate gradient smoothing with diagonal preconditioner 
% CGML_CGSMOO conjugate gradient smoothing with AINV preconditioner 
% CGML_CHEPSOPT incomplete Cholesky decomposition of a symmetric sparse matrix with threshold 
% CGML_CHEPSOPTDD incomplete Cholesky decomposition of a symmetric sparse matrix, DD ordering
% CGML_CHICOPT incomplete Cholesky decomposition of a symmetric sparse matrix, same structure as A 
% CGML_CHICOPTDD incomplete Cholesky decomposition of a symmetric sparse matrix, DD ordering 
% CGML_CHLEVOPT incomplete Cholesky decomposition of a symmetric sparse matrix by levels
% CGML_CINFLU4DD computes the influence matrix of the fine level to pass it to the graph partitioner
% CGML_COARSENCLJP CLJP coarsening algorithm, find the fine and coarse nodes
% CGML_COARSENFALG Falgout coarsening algorithm, find the fine and coarse nodes
% CGML_COARSENHMIS HMIS coarsening algorithm, find the fine and coarse nodes
% CGML_COARSENM2 find the fine and coarse nodes: my own algorithm
% CGML_COARSENP variant of the parallel LLNL coarsening algorithm (Falgout and al)
% CGML_COARSENP1 another variant of the parallel LLNL coarsening algorithm  (Falgout & al)
% CGML_COARSENPMIS PMIS coarsening algorithm, find the fine and coarse nodes
% CGML_COARSENSTIN find the fine and coarse nodes algorithm mainly for 'im' and 'iz' interpolations 
% CGML_COARSENSTLOC1 find the fine and coarse nodes standard AMG algorithm 
% CGML_COARSENSTLOC2 find the fine and coarse nodes standard AMG algorithm 
% CGML_COARSENSTMZ standard AMG coarsening algorithm + check for M or Z
% CGML_COARSENSTN1 standard AMG coarsening + addition of a few coarse nodes at the end using Brandt's idea
% CGML_COARSENSTNEW standard AMG coarsening algorithm, find the fine and coarse nodes
% CGML_COARSENO find the coarse nodes and neigbours of i in S
% CGML_COARSENO1 find the coarse nodes and neigbours of i in S
% CGML_COARSENO2 find the coarse, fine nodes and neigbours of i in S
% CGML_COMPONENTS connected or strongly connected components of a graph
% CGML_COMPR compress the list of integers by deleting extra copies of elements
% CGML_DICE separate a graph recursively
% CGML_DICE_WITH_NODE_SEP  separate a graph recursively with a separator
% CGML_ENERMIN computes the energy minimizing interpolation
% CGML_EVMCARRE least squares polynomial times r
% CGML_FIEDLE Fiedler vector of a graph
% CGML_FILMATR filters the matrix A 
% CGML_FINDCOARSE find the elements of c in f and ovl even if duplicated
% CGML_FMT for two lists of integers computes f\t
% CGML_GERSCHGO computes the Gerschgorin bounds for a matrix A
% CGML_GMESH generates the coordinates of the nodes for an m x m mesh
% CGML_GPLOTPART plot a partitioned graph in 2 or 3 dimensions
% CGML_GRAPH_COLOR colors the graph of A
% CGML_GRAPH_COLOR1 colors the graph of A
% CGML_GRAPH_COLORB colors the graph of A
% CGML_GSSMOOTH Gauss Seidel smoothing for AMG
% CGML_ICBOPT  block incomplete Cholesky decomposition IC(0) of a sparse matrix
% CGML_ICSMOOTH  Richardson smoothing with IC for AMG
% CGML_ICSMOOTHB  Richardson smoothing with block IC
% CGML_IND_SET finds an independent set 
% CGML_INERTPART  inertial partition of a graph (geometry)
% CGML_INFLU influence matrix of a, same as influin 
% CGML_INFLUIN influence matrix of M
% CGML_INFLUM influence matrix of A, |a(i,j)| > 0 
% CGML_INFLUMT influence matrix of A, |a(i,j)| > 0, q largest elements
% CGML_INFLUST influence matrix of A, standard AMG
% CGML_INFLUSTB influence matrix of A standard AMG choice
% CGML_INFLUSTB1 influence matrix of A standard AMG choice
% CGML_INFLUSTBL block influence matrix of A
% CGML_INITPRECB computes many preconditioners for CG
% CGML_INTERS computes intersection of two lists of integers
% CGML_INTERSECT set intersection
% CGML_INVPERM inverse permutation of perm
% CGML_LAPLACIAN Laplacian matrix of a graph
% CGML_LAP_5 Laplacian matrix (5-point) using sparse
% CGML_LAP_9 Laplacian matrix (9-point) using sparse
% CGML_MATSMOOTH  Richardson smoothing with A
% CGML_MAXNZPR maximum number of non zeros per row of A
% CGML_MESHSQ coordinates of an mxm mesh of the unit square
% CGML_MILUK Manteuffel shifted ILU factorization
% CGML_NEIGHB find the neigbours for i in the graph of S
% CGML_NEIGHB1 find the neigbours for i in the graph of S
% CGML_NEIGHBOSET set of the nodes which are at distance k from node i
% CGML_NEIGHBOURS_BY_FRONT enlarge the Inside Nodes of a given Subdomain with layers sets of neighbours
% CGML_NEIGHBS find the neigbours for i in the graph of S
% CGML_NEIGHBSET set of the nodes which are at distance k of node i 
% CGML_NORMALIZ symmetrically scales the matrix A with 1's on the diagonal
% CGML_NORMFROB1 returns the matrix of the Frobenius norms of the blocks of A
% CGML_OTHER find the other part of a partition
% CGML_PARTITION partition points by a plane
% CGML_PCG preconditioned conjugate gradient for a matrix A with different preconditioners
% CGML_PLOTGRID plot the AMG coarse meshes on the graph for a square mesh
% CGML_PLOTGRIDS1 plot the mg coarse meshes on the graph for a square mesh
% CGML_PLOTGRIDSP plot the mg coarse meshes on the graph
% CGML_PLOTSQ plots a filled red square at position x,y
% CGML_PLOTSQC plots a filled  square of color 'c' at position x,y
% CGML_PLOTSQG plots a filled green square at position x,y
% CGML_POLSMOOTH  Richardson smoothing with polynomial precond
% CGML_PTINDEX computes the point index from the block index in block AMG
% CGML_PTS translates the block influence matrix S to point form
% CGML_RCMPART partition of a graph from a Reverse Cuthill-McKee matrix reordering
% CGML_RECURSIVE_DECOUP recursive splitting with partitioning
% CGML_RECURSIV_DECOUP_OVERLAP  recursive partitioning of a graph with overlapping
% CGML_SAINVN1 sparse approximate inverse of Benzi (SISSC 97), stabilized version of cgml_ainv1
% CGML_SAINVN2 sparse approximate inverse of Benzi and Tuma (SISSC 97), stabilized version of cgml_ainvn2
% CGML_SAINVN4 sparse approximate inverse of Benzi and Tuma (SISSC 97), stabilized version of cgml_ainvn4
% CGML_SAINVN4DD sparse approximate inverse of Benzi and Tuma (SISSC 97), domain decomposition ordering
% CGML_SAISMOOTH SAI Richardson smoothing for AMG
% CGML_SAITW  sparse approximate inverse of Tang ang Wan
% CGML_SD_REORDER find new ordering from a given numbering obtained by graph partitioning
% CGML_SETDIFF set difference
% CGML_SETMCARRE computes the coefficients of the least squares polynomial
% CGML_SGSSMOOTH symmetric Gauss Seidel smoothing for AMG
% CGML_SGSSMOOTHB symmetric block Gauss Seidel smoothing 
% CGML_SGSSMOOTHN  block Gauss Seidel smoothing 
% CGML_SOLVEPRECB solves M z = r
% CGML_SPECPART spectral partition of a graph
% CGML_TRILB block lower triangular part of a with blocks of order tb
% CGML_UNIQUE set unique
% CGML_VTXSEP convert an edge separator (or node partition) to a vertex separator
% CGML_WAGINT computes the interpolation weights inspired by Wagner's interpolation
% CGML_WGHT weights from the influence matrix S
% CGML_WGHT1 weights from the matrix A (approximate inverse)
% CGML_WGHT_CLJP weights for the (modified) CLJP algorithm
% CGML_WGHT_R weights for the CLJP and PMIS algorithms
% CGML_WINTERP computes the interpolation weights, standard AMG interpolation
% CGML_WINTINV computes the interpolation weights using AINV interpolation
% CGML_WMEUR computes the interpolation weights, Meurant's algorithm
% CGML_ZERODD put to zero the components a(i) of vector a such that nsd(i)~=nsd(k) if nsd(k) and nsd(i) ~= 0