function [s]=cgml_cinflu4dd(a,alpmax,alb,lmax,falp,qmin,alq,smooth,infl,coarse,interpo,iprint);
%CGML_CINFLU4DD computes the influence matrix of the fine level to pass it to the graph partitioner
% domain decomposition ordering
%
% smooth = smoother
% infl = mode of computation of the influence matrix
% coarse = coarsening algorithm
% interpo = interpolation algorithm
% nsd = subdomain number or 0 (interfaces) and -1 (corner points)
%
% s influence matrix
%
% author G. Meurant
% June 2001
%

alp=alpmax;
alpb=alb;
q=qmin;

% we are on the fine level
l=1;
n=size(a,1);
if iprint > 1
 str=sprintf('level=%g',l);
 str1=sprintf(', n=%g',n);
 disp(' ')
 disp(['-------influence matrix---------- ' str str1])
 disp(' ')
end

if infl ~= 'a' & infl ~= 'b'
 % we need to compute the smoother only if the computation of
 % the influence matrix uses it
 nom=1;
 if infl == 'm'
  nom=0;
 elseif infl == 'mc' | infl == 'mt' | infl == 'mu' | infl == 'mi'
  nom=0;
 end
  
 % AINV smoother or preconditoner for CG smoother
 if smooth == 'ai' | smooth == 'cg'
  % AINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet=0;
  beta=bet*max(max(abs(a)));
  as=a+beta*speye(n);
  [za,pa,zb,pb]=cgml_ainvn4(as,alp,alpb,q);
  if nnz(find(pa<0)) ~= 0
   error('CINFLU4DD: non positive definite matrix')
  end
  % compute the preconditioner M = Z P Z'
  m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  
 elseif smooth == 'sa' 
  % SAINV factorization, keep only the q largest elements
  % use eventually a shifted matrix
  bet=0;
  beta=bet*max(max(abs(a)));
  as=a+beta*speye(n);
  [za,pa,zb,pb]=cgml_sainvn4(as,alp,alpb,q);
  if nnz(find(pa<0)) ~= 0
   error('CINFLU4DD: non positive definite matrix on level')
  end
  % compute the preconditioner M = Z P Z'
  m=za*spdiags(pa,0,n,n)*za';
  spa=spdiags(sqrt(pa),0,n,n);
  zap=za*spa;
  
 elseif smooth == 'tw'
 % Tang approximate inverse
  m=cgml_saitw(a,0,1);
  za=m;
  zap=m;
  spa=m;
  
 elseif smooth == 'po'
  % polynomial smoothing
  [lmi,lma]=cgml_gerschgo(a);
  lmi=max(0,lmi);
  degpol=1;
  m=cgml_setmcarre(degpol,lmi,lma);
  za=a;
  zap=a;
  spa=a;
  
 elseif smooth == 'gs' | smooth == 'ga'
  % Symmetric Gauss-Seidel smoother
  tl=tril(a);
  tu=triu(a);
  im=tl*diag(1./diag(a))*tl';
  m=inv(im);
  za=tl;
  zap=a;
  spa=a;
  
 elseif smooth == 'ic' | smooth == 'id'
  % Incomplete Cholesky smoother
  % IC(0) of a general matrix
  [dd,ll]=cgml_chicopt(a);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CINFLU4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  if nom == 0
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
  end
  za=ll;
  zap=a;
  spa=a;
  
 elseif smooth == 'ch' | smooth == 'cd'
  % Incomplete Cholesky with fill
  % IC(epsilon) of a general matrix
  [dd,ll]=cgml_chepsopt(a,alb);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CINFLU4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  if nom == 0
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
  end
  za=ll;
  zap=a;
  spa=a;
  
 elseif smooth == 'lv'
  % Incomplete Cholesky with levels
  % IC(level) of a general matrix
  [dd,ll]=cgml_chlevopt(a,alb);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CINFLU4DD: Pb with incomplete factorization')
  end
  dd=1./dd;
  if nom == 0
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
  end
  za=ll;
  zap=a;
  spa=a;
  
 elseif smooth == 'sh'
  % Incomplete Cholesky of Manteuffel with shift and levels
  % IC(level) of a general matrix
  % 3 retries
  [lu,bdown]=cgml_miluk(a,alb,3);
  ll=tril(lu);
  dd=diag(ll);
  ind=find(dd<0);
  if length(ind) ~= 0
   error('CINFLU4DD: Pb with incomplete factorization')
  end
  if nom == 0
   il=inv(ll);
   m=il'*spdiags(dd,0,n,n)*il;
  end
  za=ll;
  zap=a;
  spa=a;
  
 elseif smooth == 'gc'
  % CG with diagonal preconditioner smoother
  dd=1./diag(a);
  za=a;
  m=a;
  zap=a;
  spa=a;

 elseif smooth == 'bj'
  % tridiagonal smoother 
  % corresponds to Block Jacobi for a rectangular mesh
  dd=diag(diag(a,0),0)+diag(diag(a,-1),-1)+diag(diag(a,1),1);
  za=a;
  m=a;
  zap=a;
  spa=a;
 else
  error('CINFLU4DD: smoother not implemented')
 end
end
 
% influence matrix
%

if infl == 'm'
 % use M to define the coarse grid
 s=cgml_influm(m);

elseif infl == 'mi'
 % variants of M (when there is not enough coarse nodes)
 % better to use 2 values of alpha
 s=cgml_influin(a,m,alp);
 
elseif infl == 'mc'
 s=cgml_influ(m,alp);
 
elseif infl == 'mt' | infl == 'mu'
 s=cgml_influmt(m);
 
elseif infl == 'z'
 % use Z to define the coarse grid
 zzt=zap+zap'-spa;
 s=cgml_influm(zzt);
 
elseif infl == 'zc'
 % variants of Z (see above)
 zzt=zap+zap'-spa;
 s=cgml_influ(zzt,alp);
 
elseif infl == 'zi'
 zzt=zap+zap'-spa;
 s=cgml_influin(a,zzt,alp);
 
elseif infl == 'zt' | infl == 'zu'
 zzt=zap+zap'-spa;
 s=cgml_influmt(zzt);
 
elseif infl == 'b'
 % same as 'a' except keeps at least one element per row
 s=cgml_influstb(a,alp);
 
else
 % corresponds to 'a': standard algorithm using A
 % and the strong connections defined by alpha
 s=cgml_influst(a,alp);
end

