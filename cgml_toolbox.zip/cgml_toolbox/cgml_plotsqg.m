function []=cgml_plotsqg(x,y);
%CGML_PLOTSQG plots a filled green square at position x,y
%
% Author G. Meurant
% Aug 2001
%

xmax=max(x);
xmin=min(x);
ymax=max(y);
ymin=min(y);
l=min(xmax-xmin,ymax-ymin);
% suppose that we are in the unit square
epsi=max(l/120,0.0001);
epsi=max(epsi,1/120);
for i=1:length(x)
 xx(1)=x(i)-epsi;
 yy(1)=y(i)-epsi;
 xx(2)=xx(1);
 yy(2)=y(i)+epsi;
 xx(3)=x(i)+epsi;
 yy(3)=yy(2);
 xx(4)=xx(3);
 yy(4)=y(i)-epsi;
 xx(5)=xx(1);
 yy(5)=yy(1);
 fill(xx,yy,'g')
end
