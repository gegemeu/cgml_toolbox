function a=cgml_lap_5(m);
%CGML_LAP_5 Laplacian matrix (5-point) using sparse
%  
% Author G. Meurant
%

t=cputime;
n=m^2;
e=ones(n,1);
e1=e;
e1(m:m:n)=0;
i=[1:n]';

a=sparse(i(2:n),i(2:n)-1,-e1(1:n-1),n,n);
a=a+sparse(i(m+1:n),i(m+1:n)-m,-e(1:n-m),n,n);
a=sparse(i,i,4*e,n,n)+a+a';

tt=cputime-t;
disp(' ')
fprintf('CGML_LAP_5, time=%g sec\n',tt)
