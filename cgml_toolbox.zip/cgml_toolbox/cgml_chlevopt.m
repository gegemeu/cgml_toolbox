function [d,l]=cgml_chlevopt(a,levmax);
%CGML_CHLEVOPT Incomplete Cholesky decomposition of a symmetric sparse matrix by levels
% l d l' with d vector and l unit lower triangular
%
% Author G. Meurant
% March 2001
%
 
n=size(a,1);
b=a;
levm=100;
lev=spones(a);

for k=1:n-1
 m=size(b,1); 
 b1=1/b(1,1);
 ii=find(b(:,1));
 sl=sparse(ii,1,b(ii,1)*b1,m,1);
 l(k:n,k)=sl;
 % dropping strategy
 %j=2;
 %for i=k+1:n
 % if lev(j,1) > levmax
 %  l(i,k)=0;
 %  lev(j,1)=levm;
 % end
 % j=j+1;
 %end
 i=find(lev(2:end,1)>levmax);
 l(i+k,k)=zeros(length(i),1);
 lev(i+1,1)=levm*ones(length(i),1);
 l(k,k)=1;
 d(k)=b(1,1);
 % Schur complement
 level=lev;
 %b=b(2:m,2:m)-b(1,1)*l(k+1:n,k)*l(k+1:n,k)';
 ind=find(l(k+1:n,k))';
 sl=sl(2:m);
 bb=b(2:m,2:m);
 lev=level(2:m,2:m);
 % do not take care of symmetry (faster)
 for i=ind
  bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
  j=find(b(i+1,:)~=0)-1;
  indj=cgml_fmt(ind,j);
  ll=level(i+1,1);
  lev(i,indj)=ll+level(indj+1,1)';
 end
 b=bb;
end
l(n,n)=1;
d(n)=b(1,1);
d=d';
 