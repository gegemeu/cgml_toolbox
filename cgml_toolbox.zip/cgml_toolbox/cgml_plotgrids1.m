function []=cgml_plotgrids1(cs,cw,lmax);
%CGML_PLOTGRIDS1 plot the mg coarse meshes on the graph for a square mesh
% cs and cw are cell arrays
% w=-100 coarse point
% this routine assumes a lexicographic ordering of the mesh points
%
% Author G. Meurant, Aug 2001
%
% fine grid
n=size(cs{1},1);
xy=gmesh(sqrt(n));
xw=xy;
gplot(cs{1},xw)
pause

% go down the grids
for l=1:lmax
 gplot(cs{l},xw)
 hold on
 w=cw{l};
 xz=xw;
 ind=find(w == -100);
 if length(ind) > 0
  xw=xw(ind,:);
  plotsq(xw(:,1),xw(:,2))
 end
 ind=find(w ~= -100);
 if length(ind) > 0
  xz=xz(ind,:);
  plotsqg(xz(:,1),xz(:,2))
 end
 tit=['l = ' num2str(l) ', nb of points = ' num2str(size(cs{l},1)) ', nb of (red) C points = ' num2str(length(xw))];
 title(tit)
 pause
 hold off
end
hold off
