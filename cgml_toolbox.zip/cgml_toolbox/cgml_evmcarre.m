function z=cgml_evmcarre(a,r,s,lmin,lmax);
%CGML_EVMCARRE Least squares polynomial times r
%  
% Author G. Meurant
%

n=size(a,1);
k=size(s,1)-2;
z=zeros(n,k+1);
ss=sum(s(1:k+2).^2);
b=s/ss;

z(:,k+1)=b(k+2)*r;
z(:,k)=b(k+1)*r+(2/(lmax-lmin))*(2*a*z(:,k+1)-(lmax+lmin)*z(:,k+1));

for j=k-1:-1:1
 z(:,j)=b(j+1)*r+(2/(lmax-lmin))*(2*a*z(:,j+1)-(lmax+lmin)*z(:,j+1))-z(:,j+2);
end

u=(4/(lmin-lmax))*s(k+1)*z(:,k+1);
for j=k-1:-1:1
 u=(4/(lmin-lmax))*s(j+1)*z(:,j+1)+u;
end
z=sqrt(2/pi)*(2/(lmin-lmax))*z(:,1)+u;

