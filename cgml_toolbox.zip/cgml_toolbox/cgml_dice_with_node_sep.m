function [maps] = cgml_dice_with_node_sep(method,levels,A,xy);
%CGML_DICE_WITH_NODE_SEP : Separate a graph recursively with a separator
%
% partitions the mesh or graph A recursively by a specified method
%
% Input:
%   'method' is the name of the 2-way edge separator function to call
%   levels   is the number of levels of partitioning
%   A        is the adjacency matrix of the graph
%
% Output:
%   maps     is a vector of integers indexed by vertex,
%				 giving the subdomain number (from 1 to 2^levels), or the VERTEX
%				 separator (negative number)
%
% From P. Leca  - inspired by J. Gilbert software
% (may 2001)

minpoints = 8;   % Don't separate pieces smaller than this.

nargcall = nargin - 2;

n = size(A,1);
Aone = spones(A);
sepflag = - 2^levels - 10000;

if n < minpoints | levels < 1
 maps = zeros(1,n);

else
 if nargcall == 2
  a = feval(method, A, xy);
 else
  a = feval(method, A);
 end

 [vs, a1,a2] = cgml_vtxsep(Aone,a);

 % Calls recursively
 if nargcall == 2
  xya1 = xy(a1,:);
  xya2 = xy(a2,:);
  [mapsa] = cgml_dice_with_node_sep(method,levels-1,A(a1,a1),xya1);
  [mapsb] = cgml_dice_with_node_sep(method,levels-1,A(a2,a2),xya2);
 else
  [mapsa] = cgml_dice_with_node_sep(method,levels-1,A(a1,a1));
  [mapsb] = cgml_dice_with_node_sep(method,levels-1,A(a2,a2));
 end

 % Set up the whole map
 maps = zeros(1,n);
 if ~isempty(mapsa)
  mapsb = mapsb + max(mapsa) + 1;
 else
  mapsb = mapsb + 1;
 end;
 maps(a1) = mapsa;
 maps(a2) = mapsb;
 maps(vs) = sepflag;
end

