function s=cgml_influstb2(a,alp);
%CGML_INFLUSTB2 influence matrix of a standard AMG choice
%
% computes a sparse matrix s of ones where
% |a(i,j)| >= alp * max_i |a(i,k)|
% keep at least two elements per row
% optimized version of cgml_influstb???
%
% author G. Meurant
% Mar 2009
% corrected Sept 2010
% October 2014
%
 
maxs=max(abs(a'))';
a=a-diag(diag(a));

if nnz(a) == 0
 disp('CGML_INFLUSTB: A is diagonal')
 s=spones(a);
 return
end

n=size(a,1);

c=abs(a)-alp*maxs*ones(1,n);

s=spones(c>=0);

% correction to avoid zero rows

for i = 1:size(a,1)
 ss = s(i,:);
 if nnz(ss) <= 1
  aa = abs(a(i,:));
  naa = length(aa);
  [y,j]=sort(aa);
  s(i,j(naa)) = 1;
  s(i,j(naa-1)) = 1;
 end
end

