function [l]=cgml_compr(list);
%CGML_COMPR compress the list of integers by deleting extra copies of elements
%
% Author G. Meurant
% 2000
 
m=size(list,1);
trans=0;
if m ~= 1
 list=list';
 trans=1;
end

zero=0;
ind=find(list == 0);
if length(ind) ~= 0
 zero=1;
end

n=length(list);
% zeroing the duplicates
for i=1:n
 li=list(i);
 ind=find(list == li);
 list(ind)=zeros(1,length(ind));
 list(i)=li;
end

% delete the zeros
ind=find(list);
l=list(ind);
if zero == 1
 l=[0 l];
end

if trans == 1
 l=l';
end


 