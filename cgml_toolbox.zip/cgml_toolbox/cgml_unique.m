function [b] = cgmpl_unique(a);
%CGML_UNIQUE Set unique
%   B = CGML_UNIQUE(A) for the array A returns the same values as in A but
%   with no repetitions
%

numelA = numel(a);


% Handle empty: no elements

if (numelA == 0)
 b=[];
 return

elseif (numelA == 1)
 % Scalar A: return the existing value of A
 b = a;
 return

 % General handling
else

 % Convert to double array for purposes of faster sorting
 % Additionally, UNIQUE calls DIFF, which requires double input

 whichclass = class(a);
 isdouble = strcmp(whichclass,'double');

 if ~isdouble
  a = double(a);
 end

 % Sort if unsorted.  Only check this for long lists.

 checksortcut = 1000;

 if numelA <= checksortcut || ~(issorted(a))
  b = sort(a);
 else
  b = a;
 end

 % d indicates the location of non-matching entries

 db = diff(b);

 d = db ~= 0;

 d(1,numelA) = 1;    % Final element is always member of unique list

 b = b(d);         % Create unique list by indexing into sorted list

 % Re-convert to correct output data type using FEVAL
 if ~isdouble
  b = feval(whichclass,b);
 end
end




