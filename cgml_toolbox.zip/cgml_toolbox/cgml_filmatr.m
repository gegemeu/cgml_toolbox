function b=cgml_filmatr(a,alp);
%CGML_FILMATR filters the matrix a 
% relative criteria
%
% Author G. Meurant
%

[n,m]=size(a);
maxa=max(max(abs(a)));
b=sparse(n,m);

for i=1:n
 ind= find(abs(a(i,:)) >= alp*maxa);
 ind=cgml_fmt(ind,[i]);
 ind=sort([i ind]);
 b(i,ind)=a(i,ind);
end
