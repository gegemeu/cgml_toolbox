function x=cgml_matsmooth(a,m,b,x0,nu);
%CGML_MATSMOOTH  Richardson smoothing with a
%
% nu iterations
%
% Author G. Meurant
% Sept 2000
%

x=x0;

for i=1:nu
 r=b-a*x;
 z=m*r;
 x=x+z;
end

