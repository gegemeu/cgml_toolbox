function [f,c,w]=cgml_coarsenm2(a,ss,m,alp);
%CGML_COARSENM2 find the fine and coarse nodes: my own algorithm
% s is an influence matrix computed by influm
%
% Author G. Meurant
% Aug 2000
%

bet=1;
f=[];
c=[];
n=size(m,1);
[w,iw]=cgml_wght1(m);
s=ss;
if nnz(s) == 0
 error('CGML_COARSENM2: S is empty, could not work!')
end
dim=0;
maxw=max(w);

% first pass
while dim < n
 % flag the node with maximum weight as Coarse
 [y,i]=max(w);
 w(i)=-100;
 % c=c U {i}
 c=[c i];
 dim=dim+1;
 
 % flag the influences as F points
 ind=find(s(:,i) > 0 & w' > -50);
 w(ind)=-50;
 dim=dim+length(ind);
 f=[f ind'];
 
 % find the points which influences the new F points
 % for all j in ind
 for j=ind'
  indk=find(s(:,j) >0 & w' > -50);
  for k=indk'
   % increase their value
   w(k)=w(k)+bet*maxw;
  end
 end
end
 
% optional second pass
nosecpass=0;
if nosecpass == 1
 dimf=length(f);
 t=[];
 dimt=0;
 while dimt ~= dimf
  fmint=cgml_setdiff(f,t);
  i=fmint(1);
  t=[t i];
  dimt=dimt+1;
  done=0;
  % coarse nodes c_i, neighbours indi
  [ci,indi]=cgml_coarsno(s,w,i);
  dis=cgml_setdiff(indi,ci);
  % check if all neighbours of i in s are f nodes
  if length(ci) == 0
   % flag i as a c node and exit
   f=cgml_fmt(f,[i]);
   c=[c i];
   dimf=dimf-1;
   w(i)=-100;
   done=1;
  end
  % diw weak neighbours in A (need the neighbours!)
  diw=[];
  cib=[];
  while ~done
   if length(dis) == 0
    done=1;
   else
    for k=dis
     indk=find(s(k,:) > 0);
     ki=cgml_intersect(indk,ci);
     if length(ki) ~= 0
      done=1;
     else
      if length(cib) ~= 0
       c=[c i];
       w(i)=-100;
       f=cgml_setdiff(f,[i]);
       dimf=dimf-1;
       break
      else
       cib=k;
       ci=[ci k];
       dis=cgml_setdiff(dis,[k]);
       done=0;
       break
      end
     end
    end
   end
  end
  if length(cgml_intersect(f,[i])) ~= 0
   c=[c cib];
   w(cib)=-100;
   f=cgml_setdiff(f,cib);
   dimf=dimf-length(cib);
  end
 end
end

% check if all f points have a c point in ss
for i=f
 [ci,indi]=cgml_coarsno(ss,w,i);
 if length(ci) == 0
  % flag i as a c node and exit
  f=cgml_setdiff(f,[i]);
  c=[c i];
  w(i)=-100;
 end
end

 
 
 