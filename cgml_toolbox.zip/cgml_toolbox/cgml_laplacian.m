function L = cgml_laplacian(A);
%CGML_LAPLACIAN Laplacian matrix of a graph
%
% L = laplacian(A)  returns a matrix whose nonzero structure is that of A+A'
%             (including any explicit zeros in A) with all values -1,
%             plus a diagonal to make all row sums zero.
%             This is the Laplacian matrix of the graph, which is positive
%             semidefinite, with an eigenvalue 0 of multiplicity equal to
%             the number of connected components
%
% From John Gilbert
% 9 March 1993
%

[n,m] = size(A);
if n ~= m
 error ('CGML_LAPLACIAN: Matrix must be square')
end

L = - spones(A|A');
L = L - diag(sum(L));
if ~issparse(A)
    L = full(L);
end
