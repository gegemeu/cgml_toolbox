function w=cgml_wght_cljp(a,s);
%CGML_WGHT_CLJP weights for the (modified) CLJP algorithm
%
% a matrix of the problem, s influence matrix
%
% Author G. Meurant
% Feb 2009
%

n=size(a,1);
w=zeros(1,n);

% color the graph of a
[ncolor,color]=cgml_graph_colorb(a);

cw=([1:ncolor]'-1)/ncolor;

rand('state',0);
randn('state',0)

for i=1:n
 % modified CLJP weights
 w(i)=nnz(s(:,i))+rand/ncolor+cw(color(i));
 % usual CLJP weights
 %w(i)=nnz(s(:,i))+rand;
 % other possibility 
 %w(i)=nnz(s(:,i))+randn;
end

 
