function s=cgml_influm(a);
%CGML_INFLUM influence matrix of a, |a(i,j)| > 0 
% computes a sparse matrix s of ones where
% |a(i,j)| > 0 except on the diagonal
%
% author G. Meurant
% Aug 2000
%
 
n=size(a,1);
s=sparse(n,n);
% scan all rows
for i=1:n
 ind= find(abs(a(i,:)) > 0);
 s(i,ind)=spones(ind);
end
% remove the diagonal
s=s-diag(diag(s));
if nnz(s) == 0
 error('CGML_INFLUM: influm, S is empty!')
end
