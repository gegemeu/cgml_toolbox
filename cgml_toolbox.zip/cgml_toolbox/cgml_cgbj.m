function x=cgml_cgbj(a,d,b,x0,nu);
%CGML_CGBJ conjugate gradient smoothing with block diagonal preconditioner
%
% preconditioner d
% rhs b
%
% Author G. Meurant
% Aug 2000
%

x=x0;
r=b-a*x;
z=d\r;
p=z;
r0=r'*r;
rtr=z'*r;

for ll=1:nu
 ap=a*p;
 alp=rtr/(p'*ap);
 x=x+alp*p;
 r=r-alp*ap;
 z=d\r;
 rk=r'*r;
 rtrz=z'*r;
 bet=rtrz/rtr;
 rtr=rtrz;
 p=z+bet*p;
end


