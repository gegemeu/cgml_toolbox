function [d,l]=cgml_chepsopt(a,epsdrop);
%CGML_CHEPSOPT Incomplete Cholesky decomposition of a symmetric sparse matrix with threshold 
%
% epsdrop = threshold for dropping elements
% d is a vector and l lower triangular with a unit diagonal
%
% Author G. Meurant
% March 2001
%
 
n=size(a,1);
b=a;
 
% norm of each row of a
for i=1:n
 anorm(i)=norm(a(i,:), inf);
end

for k=1:n-1
 m=size(b,1);
 b1=1/b(1,1);
 ii=find(b(:,1));
 sl=sparse(ii,1,b(ii,1)*b1,m,1);
 l(k:n,k)=sl;
 % dropping strategy
 %
 % for i=k+1:n
 %  if abs(l(i,k)) <= epsdrop*anorm(i)
 %   l(i,k)=0;
 %  end
 % end
 i=find(abs(l(k+1:n,k))./anorm(k+1:n)'<=epsdrop);
 l(i+k,k)=zeros(length(i),1);
 l(k,k)=1;
 d(k)=b(1,1);
 % Schur complement
 ind=find(l(k+1:n,k))';
 sl=sl(2:m);
 bb=b(2:m,2:m);
 %b=b(2:m,2:m)-b(1,1)*l(k+1:n,k)*l(k+1:n,k)';
 for i=ind
  bb(i,ind)=bb(i,ind)-b(1,1)*sl(i)*sl(ind)';
 end
 b=bb;
end
l(n,n)=1;
d(n)=b(1,1);
d=d';

