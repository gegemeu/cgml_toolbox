function xy=cgml_gmesh(m);
%CGML_GMESH generates the coordinates of the nodes for an m x m mesh
% on the unit square
%
% Author G. Meurant
% Aug 2000
%

[x,y]=meshsq(m);
xy=[x;y]';
