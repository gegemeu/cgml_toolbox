function [ft,lft,ovlt]=cgml_findcoarse(f,lf,ovl,c);
%CGML_FINDCOARSE find the elements of c in f and ovl even if duplicated
%
% return the new ordering
% and return the same for lft (number of subdomain)
%
% Author G. Meurant
% April 2002
%

if length(f) == 0 | length(c) == 0
 ft=f;
 lft=lf;
 return
end

ft=[];
lft=[];
ovlt=[];
for i=1:length(c)
 ind=find(f == c(i));
 if length(ind) > 0
  ft=[ft ones(1,length(ind))*i];
  lft=[lft lf(ind)];
  ind=find(ovl == c(i));
  if length(ind) > 0
   ovlt=[ovlt ones(1,length(ind))*i];
  end
 end % if
end % for
