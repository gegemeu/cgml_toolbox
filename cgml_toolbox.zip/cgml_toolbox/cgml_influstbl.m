function s=cgml_influstbl(a,alp,tb);
%CGML_INFLUSTBL block influence matrix of a
%
% tb is the block size
% computes a sparse matrix s (order n/tb) of ones where
% ||a(I,J)||_F >= alp * max_K ||a(I,K)||_F, I,J,K are block indices
%
% author G. Meurant
% Aug 2006
%
 
a=cgml_normfrob1(a,tb);
maxs=max(abs(a'))';
a=a-diag(diag(a));

if nnz(a) == 0
 disp('CGML_INFLUSTBL: normf(A) is block diagonal')
 s=spones(a);
 return
end

n=size(a,1);
s=sparse(n,n);

for i=1:n
 ind= find(abs(a(i,:)) >= alp*maxs(i));
 if length(ind) == 0 
  [y,j]=max(abs(a(i,:)));
  if y > 0
   ind=j;
  else
   ind=[];
  end
 end
 if length(ind) > 0
  s(i,ind)=spones(ind);
 end
end

%s=s-diag(diag(s));
if nnz(s) == 0
 error('CGML_INFLUSTBL: S is empty!')
end
 
