function x=cgml_sgssmoothn(a,dl,b,x0,nu,tb);
%CGML_SGSSMOOTHN  block Gauss Seidel smoothing 
%
% nu iterations starting from x0
% dl contains the block lower triangular part of a
% tb block size
%
% Author G. Meurant
% Aug 2006
%

x=x0;
lt=a-dl;

for i=1:nu
 x=dl\(b-lt*x);
end


