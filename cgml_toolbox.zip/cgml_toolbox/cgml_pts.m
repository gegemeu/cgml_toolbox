function ss=cgml_pts(s,tb);
%CGML_PTS translates the block influence matrix s to point form
%
% Author G. Meurant
% August 2006
%

ntb=size(s,1);
n=ntb*tb;
ss=sparse(n,n);

for I=1:tb
  ideb=(I-1)*ntb+1;
  ifin=ideb+ntb-1;
  ss(ideb:ifin,ideb:ifin)=s;
end

% permutation to blocks of order tb
p=zeros(1,n);
ii=[1:ntb];
for I=1:tb
  p(I:tb:end)=(I-1)*ntb+ii;
end
ss=ss(p,p);
