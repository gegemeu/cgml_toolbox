function l=cgml_maxnzpr(a);
%CGML_MAXNZPR maximum number of non zeros per row of a
%
% Author G. Meurant
% Feb 2001
%

aa=spones(a);
l=max(sum(aa));
